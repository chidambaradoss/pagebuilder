/**
 * Page Builder - Main Initialization File
 *
 * This file orchestrates the initialization of GrapesJS editor and all
 * custom plugins, components, and functionality.
 */

(function() {
    'use strict';

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeEditor);
    } else {
        initializeEditor();
    }

    function initializeEditor() {
        console.log('Initializing Page Builder...');

        // Initialize GrapesJS editor
        const editor = grapesjs.init(editorConfig);

        // Setup custom commands
        setupCommands(editor);

        // Load custom plugins
        headerFooterLockPlugin(editor);

        // Check if code injection plugin is loaded
        if (typeof codeInjectionPlugin !== 'undefined') {
            codeInjectionPlugin(editor);
        }

        // Register custom components
        if (typeof registerCustomComponents !== 'undefined') {
            registerCustomComponents(editor);
        }

        // Setup media manager
        if (typeof setupMediaManager !== 'undefined') {
            setupMediaManager(editor);
        }

        // Register Bootstrap blocks
        if (typeof registerBootstrapBlocks !== 'undefined') {
            registerBootstrapBlocks(editor);
        }

        // Register creative blocks
        if (typeof registerCreativeBlocks !== 'undefined') {
            registerCreativeBlocks(editor);
        }

        // Register icon blocks
        if (typeof registerIconBlocks !== 'undefined') {
            registerIconBlocks(editor);
        }

        // Register extended blocks
        if (typeof registerExtendedBlocks !== 'undefined') {
            registerExtendedBlocks(editor);
        }

        // Register template blocks
        if (typeof registerTemplateBlocks !== 'undefined') {
            registerTemplateBlocks(editor);
        }

        // Setup save functionality
        setupSaveFunction(editor);

        // Setup load functionality
        setupLoadFunction(editor);

        // Setup auto-save
        setupAutoSave(editor);

        // Editor event listeners
        editor.on('load', () => {
            console.log('Editor loaded successfully');
        });

        editor.on('update', () => {
            console.log('Editor content updated');
        });

        // Store editor globally for debugging
        window.editor = editor;

        console.log('Page Builder initialized successfully!');
    }

    /**
     * Setup Save Functionality
     */
    function setupSaveFunction(editor) {
        editor.Commands.add('save-page', {
            run(editor) {
                const wrapper = editor.getWrapper();
                const bodyContainer = wrapper.find('#page-body')[0];

                if (!bodyContainer) {
                    alert('Error: Body container not found!');
                    console.error('Body container #page-body not found');
                    return;
                }

                // Get only body content (excluding header and footer)
                const bodyHtml = editor.getHtml({ component: bodyContainer });
                const bodyCss = editor.getCss({ component: bodyContainer });
                const bodyComponents = JSON.stringify(bodyContainer.toJSON());

                const data = {
                    html: bodyHtml,
                    css: bodyCss,
                    components: bodyComponents,
                    timestamp: new Date().toISOString()
                };

                console.log('Saving page content...', data);

                // Show saving indicator
                const saveBtn = document.querySelector('[title="Save Page"]');
                if (saveBtn) {
                    saveBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i>';
                    saveBtn.disabled = true;
                }

                // POST to save endpoint
                fetch(window.PAGEBUILDER_CONFIG.apiEndpoints.save, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                })
                .then(response => response.json())
                .then(result => {
                    console.log('Save response:', result);

                    if (result.success) {
                        alert('Page saved successfully!');
                        // Also save to local storage as backup
                        editor.store();
                    } else {
                        alert('Save failed: ' + (result.message || 'Unknown error'));
                    }
                })
                .catch(error => {
                    console.error('Save error:', error);
                    alert('Save failed: ' + error.message);
                })
                .finally(() => {
                    // Restore save button
                    if (saveBtn) {
                        saveBtn.innerHTML = '<i class="fa fa-save"></i>';
                        saveBtn.disabled = false;
                    }
                });
            }
        });
    }

    /**
     * Setup Load Functionality
     */
    function setupLoadFunction(editor) {
        // Add load command
        editor.Commands.add('load-page', {
            run(editor) {
                console.log('Loading saved page...');

                fetch(window.PAGEBUILDER_CONFIG.apiEndpoints.load)
                .then(response => response.json())
                .then(result => {
                    console.log('Load response:', result);

                    if (result.success && result.data) {
                        const wrapper = editor.getWrapper();
                        const bodyContainer = wrapper.find('#page-body')[0];

                        if (bodyContainer && result.data.components) {
                            try {
                                // Parse and load components
                                const components = JSON.parse(result.data.components);
                                bodyContainer.components(components.components || components);

                                // Load CSS
                                if (result.data.css) {
                                    editor.setStyle(result.data.css);
                                }

                                console.log('Page loaded successfully');
                            } catch (error) {
                                console.error('Error parsing saved data:', error);
                                alert('Error loading saved page: ' + error.message);
                            }
                        }
                    } else {
                        console.log('No saved page found or load failed');
                    }
                })
                .catch(error => {
                    console.error('Load error:', error);
                    console.log('No saved page to load');
                });
            }
        });

        // Auto-load on editor initialization
        editor.on('load', () => {
            // Wait a bit for editor to fully initialize
            setTimeout(() => {
                editor.runCommand('load-page');
            }, 500);
        });
    }

    /**
     * Setup Auto-Save Functionality
     */
    function setupAutoSave(editor) {
        let autoSaveInterval = null;
        const AUTOSAVE_INTERVAL = 60000; // 60 seconds

        // Start auto-save
        autoSaveInterval = setInterval(() => {
            console.log('Auto-saving...');
            editor.runCommand('save-page');
        }, AUTOSAVE_INTERVAL);

        // Clear interval on page unload
        window.addEventListener('beforeunload', () => {
            if (autoSaveInterval) {
                clearInterval(autoSaveInterval);
            }
        });

        console.log('Auto-save enabled (every 60 seconds)');
    }

    /**
     * Utility: Show notification
     */
    window.showNotification = function(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            background-color: ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : '#007bff'};
            color: white;
            border-radius: 4px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    };

    // Add CSS animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(400px);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);

})();
