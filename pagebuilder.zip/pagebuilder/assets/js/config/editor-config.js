/**
 * GrapesJS Editor Configuration
 *
 * This file contains the main configuration settings for the GrapesJS editor
 * including panel layout, storage, device manager, and plugin settings.
 */

const editorConfig = {
    // Container for the editor
    container: '#gjs',

    // Editor dimensions
    height: '100vh',
    width: 'auto',

    // Storage Manager configuration
    storageManager: {
        type: 'local',
        autosave: true,
        autoload: false, // We'll load manually from server
        stepsBeforeSave: 3,
        options: {
            local: {
                key: 'gjsProject'
            }
        }
    },

    // Device Manager - Responsive preview
    deviceManager: {
        devices: [
            {
                id: 'desktop',
                name: 'Desktop',
                width: '',
            },
            {
                id: 'tablet',
                name: 'Tablet',
                width: '768px',
                widthMedia: '992px',
            },
            {
                id: 'mobileLandscape',
                name: 'Mobile Landscape',
                width: '568px',
                widthMedia: '768px',
            },
            {
                id: 'mobilePortrait',
                name: 'Mobile Portrait',
                width: '375px',
                widthMedia: '480px',
            }
        ]
    },

    // Panels configuration
    panels: {
        defaults: [
            {
                id: 'basic-actions',
                el: '.gjs-pn-commands',
                buttons: [
                    {
                        id: 'visibility',
                        active: true,
                        className: 'btn-toggle-borders',
                        label: '<i class="fa fa-clone"></i>',
                        command: 'sw-visibility',
                        attributes: { title: 'Toggle Borders' }
                    },
                    {
                        id: 'preview',
                        className: 'btn-preview',
                        label: '<i class="fa fa-eye"></i>',
                        command: 'preview',
                        attributes: { title: 'Preview' }
                    },
                    {
                        id: 'fullscreen',
                        className: 'btn-fullscreen',
                        label: '<i class="fa fa-arrows-alt"></i>',
                        command: 'fullscreen',
                        attributes: { title: 'Fullscreen' }
                    },
                    {
                        id: 'export',
                        className: 'btn-export',
                        label: '<i class="fa fa-code"></i>',
                        command: 'export-template',
                        attributes: { title: 'View Code' }
                    },
                    {
                        id: 'undo',
                        className: 'btn-undo',
                        label: '<i class="fa fa-undo"></i>',
                        command: 'undo',
                        attributes: { title: 'Undo' }
                    },
                    {
                        id: 'redo',
                        className: 'btn-redo',
                        label: '<i class="fa fa-redo"></i>',
                        command: 'redo',
                        attributes: { title: 'Redo' }
                    },
                    {
                        id: 'clear-all',
                        className: 'btn-clear',
                        label: '<i class="fa fa-trash"></i>',
                        command: 'clear-canvas',
                        attributes: { title: 'Clear Canvas' }
                    },
                    {
                        id: 'save',
                        className: 'btn-save',
                        label: '<i class="fa fa-save"></i>',
                        command: 'save-page',
                        attributes: { title: 'Save Page' }
                    }
                ]
            },
            {
                id: 'panel-devices',
                el: '.panel__devices',
                buttons: [
                    {
                        id: 'device-desktop',
                        label: '<i class="fa fa-desktop"></i>',
                        command: 'set-device-desktop',
                        active: true,
                        togglable: false,
                        attributes: { title: 'Desktop' }
                    },
                    {
                        id: 'device-tablet',
                        label: '<i class="fa fa-tablet"></i>',
                        command: 'set-device-tablet',
                        togglable: false,
                        attributes: { title: 'Tablet' }
                    },
                    {
                        id: 'device-mobile',
                        label: '<i class="fa fa-mobile"></i>',
                        command: 'set-device-mobile',
                        togglable: false,
                        attributes: { title: 'Mobile' }
                    }
                ]
            },
            {
                id: 'panel-switcher',
                el: '.panel__switcher',
                buttons: [
                    {
                        id: 'show-layers',
                        active: true,
                        label: 'Layers',
                        command: 'show-layers',
                        togglable: false,
                        attributes: { title: 'Show Layers' }
                    },
                    {
                        id: 'show-style',
                        label: 'Styles',
                        command: 'show-styles',
                        togglable: false,
                        attributes: { title: 'Show Styles' }
                    },
                    {
                        id: 'show-traits',
                        label: 'Settings',
                        command: 'show-traits',
                        togglable: false,
                        attributes: { title: 'Show Settings' }
                    }
                ]
            }
        ]
    },

    // Layer Manager configuration
    layerManager: {
        appendTo: '#layers-container',
        showWrapper: true,
        showHover: true,
        scrollCanvas: true,
        scrollLayers: true,
        hideTextnode: true,
    },

    // Style Manager configuration
    styleManager: {
        appendTo: '#styles-container',
        sectors: [
            {
                name: 'General',
                open: true,
                buildProps: ['float', 'display', 'position', 'top', 'right', 'left', 'bottom']
            },
            {
                name: 'Dimension',
                open: false,
                buildProps: ['width', 'height', 'max-width', 'min-height', 'margin', 'padding']
            },
            {
                name: 'Typography',
                open: false,
                buildProps: ['font-family', 'font-size', 'font-weight', 'letter-spacing', 'color', 'line-height', 'text-align', 'text-decoration', 'text-shadow']
            },
            {
                name: 'Decorations',
                open: false,
                buildProps: ['background-color', 'border-radius', 'border', 'box-shadow', 'background']
            },
            {
                name: 'Extra',
                open: false,
                buildProps: ['transition', 'perspective', 'transform']
            }
        ]
    },

    // Traits Manager configuration
    traitManager: {
        appendTo: '#traits-container'
    },

    // Block Manager configuration
    blockManager: {
        appendTo: '#blocks'
    },

    // Canvas configuration
    canvas: {
        styles: [
            window.PAGEBUILDER_CONFIG.bootstrapVersion === '5'
                ? 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'
                : 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'
        ],
        scripts: [
            window.PAGEBUILDER_CONFIG.bootstrapVersion === '5'
                ? 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'
                : 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js'
        ]
    },

    // Plugin configuration
    plugins: ['gjs-blocks-basic'],
    pluginsOpts: {
        'gjs-blocks-basic': {
            flexGrid: true,
            blocks: ['column1', 'column2', 'column3', 'column3-7', 'text', 'link', 'image', 'video', 'map']
        }
    },

    // Asset Manager (disabled - we use custom media manager)
    assetManager: {
        upload: false,
        uploadText: 'Drop files here or click to upload'
    }
};

// Custom commands
const setupCommands = (editor) => {
    // Device commands
    editor.Commands.add('set-device-desktop', {
        run: (editor) => editor.setDevice('Desktop')
    });

    editor.Commands.add('set-device-tablet', {
        run: (editor) => editor.setDevice('Tablet')
    });

    editor.Commands.add('set-device-mobile', {
        run: (editor) => editor.setDevice('Mobile Portrait')
    });

    // Panel switcher commands
    editor.Commands.add('show-layers', {
        run: (editor) => {
            document.querySelectorAll('.layers-container, .styles-container, .traits-container').forEach(el => {
                el.classList.remove('active');
            });
            document.querySelector('.layers-container').classList.add('active');
        }
    });

    editor.Commands.add('show-styles', {
        run: (editor) => {
            document.querySelectorAll('.layers-container, .styles-container, .traits-container').forEach(el => {
                el.classList.remove('active');
            });
            document.querySelector('.styles-container').classList.add('active');
        }
    });

    editor.Commands.add('show-traits', {
        run: (editor) => {
            document.querySelectorAll('.layers-container, .styles-container, .traits-container').forEach(el => {
                el.classList.remove('active');
            });
            document.querySelector('.traits-container').classList.add('active');
        }
    });

    // Clear canvas command
    editor.Commands.add('clear-canvas', {
        run: (editor) => {
            if (confirm('Are you sure you want to clear the canvas? This will remove all components except header and footer.')) {
                const wrapper = editor.getWrapper();
                const bodyContainer = wrapper.find('#page-body')[0];
                if (bodyContainer) {
                    bodyContainer.components().reset();
                }
            }
        }
    });

    // Export template command
    editor.Commands.add('export-template', {
        run: (editor) => {
            const modal = editor.Modal;
            const htmlCode = editor.getHtml();
            const cssCode = editor.getCss();

            modal.setTitle('Export Template');
            modal.setContent(`
                <div style="padding: 20px;">
                    <h5>HTML</h5>
                    <textarea readonly style="width:100%;height:200px;font-family:monospace;padding:10px;border:1px solid #ddd;">${htmlCode}</textarea>
                    <h5 style="margin-top:20px;">CSS</h5>
                    <textarea readonly style="width:100%;height:200px;font-family:monospace;padding:10px;border:1px solid #ddd;">${cssCode}</textarea>
                </div>
            `);
            modal.open();
        }
    });

    console.log('Editor Config: Commands loaded');
};
