/**
 * Custom Components for GrapesJS
 *
 * This file registers custom component types including the custom image
 * component that integrates with our media library.
 */

const registerCustomComponents = (editor) => {
    // First, extend the default image type to use our custom behavior
    const defaultImageType = editor.DomComponents.getType('image');
    const defaultImageModel = defaultImageType.model;
    const defaultImageView = defaultImageType.view;

    // Custom Image Component with Media Library Integration
    editor.DomComponents.addType('custom-image', {
        extend: 'image',
        isComponent: (el) => {
            if (el && el.tagName === 'IMG') {
                return { type: 'custom-image' };
            }
        },
        model: {
            defaults: {
                name: 'Image',
                traits: [
                    {
                        type: 'text',
                        name: 'alt',
                        label: 'Alt Text',
                        placeholder: 'Enter alt text'
                    },
                    {
                        type: 'select',
                        name: 'loading',
                        label: 'Loading',
                        options: [
                            { value: '', name: 'Default' },
                            { value: 'lazy', name: 'Lazy' },
                            { value: 'eager', name: 'Eager' }
                        ]
                    },
                    {
                        type: 'button',
                        name: 'select-media',
                        label: ' ',
                        text: '<i class="fa fa-images"></i> Browse Media Library',
                        command: 'open-media-library',
                    }
                ],
                attributes: {
                    class: 'img-fluid'
                }
            },
            init() {
                // Track if this is a manual drag action
                let isDragAction = false;

                // Listen for drag events
                editor.on('block:drag:start', () => {
                    isDragAction = true;
                });

                editor.on('block:drag:stop', () => {
                    setTimeout(() => {
                        isDragAction = false;
                    }, 500);
                });

                // Open media library automatically when component is added via drag
                this.on('add', () => {
                    // Don't open if we're loading the page
                    if (editor.StorageManager.isAutosave) {
                        return;
                    }

                    const src = this.get('src');
                    const isNewImage = !src || src === '' || src.includes('placeholder') || src.includes('via.placeholder');

                    // Only open for new images from drag actions, not on page load
                    if (isNewImage && isDragAction) {
                        setTimeout(() => {
                            editor.runCommand('open-media-library', { target: this });
                        }, 150);
                    }
                });
            }
        },
        view: {
            events: {
                dblclick: 'openMediaLibrary',
            },
            openMediaLibrary() {
                const component = this.model;
                editor.runCommand('open-media-library', { target: component });
            }
        }
    });

    // Replace default image blocks with custom image
    editor.on('block:drag:stop', (component) => {
        if (component.get('type') === 'image') {
            component.set('type', 'custom-image');
            // Media library will auto-open from the init() function
        }
    });

    // Also handle component:add event for images
    editor.on('component:add', (component) => {
        if (component.get('type') === 'image') {
            component.set('type', 'custom-image');
        }
    });

    // Custom Button Component with additional styles
    editor.DomComponents.addType('custom-button', {
        extend: 'link',
        model: {
            defaults: {
                name: 'Button',
                tagName: 'a',
                attributes: { class: 'btn btn-primary' },
                traits: [
                    {
                        type: 'text',
                        name: 'href',
                        label: 'Link URL',
                        placeholder: 'https://example.com'
                    },
                    {
                        type: 'select',
                        name: 'target',
                        label: 'Target',
                        options: [
                            { value: '', name: 'Same window' },
                            { value: '_blank', name: 'New window' }
                        ]
                    },
                    {
                        type: 'select',
                        name: 'button-style',
                        label: 'Button Style',
                        changeProp: 1,
                        options: [
                            { value: 'btn-primary', name: 'Primary' },
                            { value: 'btn-secondary', name: 'Secondary' },
                            { value: 'btn-success', name: 'Success' },
                            { value: 'btn-danger', name: 'Danger' },
                            { value: 'btn-warning', name: 'Warning' },
                            { value: 'btn-info', name: 'Info' },
                            { value: 'btn-light', name: 'Light' },
                            { value: 'btn-dark', name: 'Dark' },
                            { value: 'btn-link', name: 'Link' }
                        ]
                    },
                    {
                        type: 'select',
                        name: 'button-size',
                        label: 'Button Size',
                        changeProp: 1,
                        options: [
                            { value: '', name: 'Default' },
                            { value: 'btn-sm', name: 'Small' },
                            { value: 'btn-lg', name: 'Large' }
                        ]
                    }
                ]
            },
            init() {
                this.on('change:attributes:button-style', this.updateButtonClass);
                this.on('change:attributes:button-size', this.updateButtonClass);
            },
            updateButtonClass() {
                const style = this.getAttributes()['button-style'] || 'btn-primary';
                const size = this.getAttributes()['button-size'] || '';
                const classes = ['btn', style];
                if (size) classes.push(size);
                this.setClass(classes);
            }
        }
    });

    // Custom Container Component
    editor.DomComponents.addType('custom-container', {
        extend: 'default',
        model: {
            defaults: {
                name: 'Container',
                tagName: 'div',
                attributes: { class: 'container' },
                droppable: true,
                traits: [
                    {
                        type: 'select',
                        name: 'container-type',
                        label: 'Container Type',
                        changeProp: 1,
                        options: [
                            { value: 'container', name: 'Fixed' },
                            { value: 'container-fluid', name: 'Fluid' }
                        ]
                    }
                ]
            },
            init() {
                this.on('change:attributes:container-type', this.updateContainerClass);
            },
            updateContainerClass() {
                const type = this.getAttributes()['container-type'] || 'container';
                this.setClass([type]);
            }
        }
    });

    // Override default image block to use custom-image
    const imageBlock = editor.BlockManager.get('image');
    if (imageBlock) {
        imageBlock.set({
            content: {
                type: 'custom-image',
                src: 'https://via.placeholder.com/350x250/667EEA/FFFFFF?text=Click+to+Select+Image',
                attributes: { class: 'img-fluid' }
            }
        });
    }

    // Global handler: Convert ALL images to custom-image and use Media Library
    editor.on('component:mount', (component) => {
        if (component.is('image') && component.get('type') !== 'custom-image') {
            // Convert to custom-image
            component.set('type', 'custom-image');
        }
    });

    // Override default image toolbar to use Media Library
    editor.on('component:selected', (component) => {
        if (component.is('image')) {
            // Ensure it's using custom-image type
            if (component.get('type') !== 'custom-image') {
                component.set('type', 'custom-image');
            }
        }
    });

    // Intercept asset manager open requests
    editor.on('run:open-assets', (opts) => {
        const selected = editor.getSelected();
        if (selected && selected.is('image')) {
            // Stop default asset manager
            editor.stopCommand('open-assets');
            // Open our custom media library instead
            editor.runCommand('open-media-library', { target: selected });
        }
    });

    // ========== RAW HTML COMPONENT ==========
    // Custom Raw HTML Component for embedding HTML/CSS/JavaScript
    editor.DomComponents.addType('raw-html', {
        extend: 'default',
        model: {
            defaults: {
                name: 'Raw HTML',
                tagName: 'div',
                attributes: { 
                    class: 'raw-html-component',
                    'data-gjs-type': 'raw-html'
                },
                droppable: false,
                editable: false,
                stylable: true,
                'raw-html': '<p>Click "Edit Code" to add your HTML</p>',
                'raw-css': '',
                'raw-js': '',
                traits: [
                    {
                        type: 'button',
                        name: 'edit-code',
                        label: ' ',
                        text: '<i class="fa fa-code"></i> Edit Code',
                        command: 'open-raw-html-editor'
                    }
                ]
            },
            init() {
                this.on('change:raw-html change:raw-css change:raw-js', this.updateContent);
                this.updateContent();
            },
            updateContent() {
                const html = this.get('raw-html') || '';
                const css = this.get('raw-css') || '';
                const js = this.get('raw-js') || '';
                
                // Create unique ID for scoped styles
                const uid = this.getId();
                
                // Build the complete content
                let content = '';
                
                // Add CSS with scoped styles
                if (css.trim()) {
                    content += `<style id="raw-css-${uid}">${css}</style>`;
                }
                
                // Add HTML content
                content += html;
                
                // Add JavaScript (wrapped in IIFE to avoid conflicts)
                if (js.trim()) {
                    content += `<script id="raw-js-${uid}">
                        (function() {
                            try {
                                ${js}
                            } catch(e) {
                                console.error('Raw HTML Component Error:', e);
                            }
                        })();
                    </script>`;
                }
                
                // Update component's inner content
                this.components(content);
            }
        },
        view: {
            events: {
                dblclick: 'openCodeEditor',
            },
            openCodeEditor() {
                const component = this.model;
                editor.runCommand('open-raw-html-editor', { target: component });
            }
        }
    });

    // Command to open raw HTML editor
    editor.Commands.add('open-raw-html-editor', {
        run(editor, sender, opts = {}) {
            const target = opts.target || editor.getSelected();
            if (!target) return;

            const html = target.get('raw-html') || '';
            const css = target.get('raw-css') || '';
            const js = target.get('raw-js') || '';

            // Create modal HTML
            const modalId = 'raw-html-editor-modal';
            
            // Remove existing modal if any
            const existingModal = document.getElementById(modalId);
            if (existingModal) {
                existingModal.remove();
            }

            // Create modal
            const modal = document.createElement('div');
            modal.id = modalId;
            modal.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.8);
                z-index: 10000;
                display: flex;
                align-items: center;
                justify-content: center;
            `;

            modal.innerHTML = `
                <div style="background: #2c3e50; border-radius: 8px; width: 90%; max-width: 1200px; height: 90%; display: flex; flex-direction: column; box-shadow: 0 4px 20px rgba(0,0,0,0.5);">
                    <!-- Header -->
                    <div style="padding: 20px; border-bottom: 2px solid #34495e; display: flex; justify-content: space-between; align-items: center;">
                        <h3 style="margin: 0; color: #ecf0f1; font-family: Arial, sans-serif;">
                            <i class="fa fa-code"></i> Raw HTML Editor
                        </h3>
                        <button id="close-raw-editor" style="background: #e74c3c; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-size: 14px;">
                            <i class="fa fa-times"></i> Close
                        </button>
                    </div>
                    
                    <!-- Tabs -->
                    <div style="display: flex; background: #34495e; padding: 0 20px;">
                        <button class="raw-editor-tab active" data-tab="html" style="background: #2c3e50; color: #e44d26; border: none; padding: 12px 24px; cursor: pointer; border-top-left-radius: 4px; border-top-right-radius: 4px; font-weight: bold; margin-right: 4px;">
                            <i class="fab fa-html5" style="font-size: 18px;"></i> HTML
                        </button>
                        <button class="raw-editor-tab" data-tab="css" style="background: transparent; color: #ecf0f1; border: none; padding: 12px 24px; cursor: pointer; border-top-left-radius: 4px; border-top-right-radius: 4px; margin-right: 4px;">
                            <i class="fab fa-css3-alt" style="font-size: 18px;"></i> CSS
                        </button>
                        <button class="raw-editor-tab" data-tab="js" style="background: transparent; color: #ecf0f1; border: none; padding: 12px 24px; cursor: pointer; border-top-left-radius: 4px; border-top-right-radius: 4px;">
                            <i class="fab fa-js-square" style="font-size: 18px;"></i> JavaScript
                        </button>
                    </div>
                    
                    <!-- Content -->
                    <div style="flex: 1; padding: 20px; overflow: hidden; display: flex; flex-direction: column;">
                        <div id="html-tab-content" class="raw-editor-content" style="display: block; flex: 1;">
                            <label style="color: #ecf0f1; margin-bottom: 8px; display: block; font-weight: bold;">HTML Code:</label>
                            <textarea id="raw-html-input" style="width: 100%; height: 100%; background: #1e272e; color: #ecf0f1; border: 1px solid #34495e; border-radius: 4px; padding: 12px; font-family: 'Courier New', monospace; font-size: 14px; resize: none;">${html.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</textarea>
                        </div>
                        <div id="css-tab-content" class="raw-editor-content" style="display: none; flex: 1;">
                            <label style="color: #ecf0f1; margin-bottom: 8px; display: block; font-weight: bold;">CSS Code:</label>
                            <textarea id="raw-css-input" style="width: 100%; height: 100%; background: #1e272e; color: #ecf0f1; border: 1px solid #34495e; border-radius: 4px; padding: 12px; font-family: 'Courier New', monospace; font-size: 14px; resize: none;">${css.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</textarea>
                        </div>
                        <div id="js-tab-content" class="raw-editor-content" style="display: none; flex: 1;">
                            <label style="color: #ecf0f1; margin-bottom: 8px; display: block; font-weight: bold;">JavaScript Code:</label>
                            <textarea id="raw-js-input" style="width: 100%; height: 100%; background: #1e272e; color: #ecf0f1; border: 1px solid #34495e; border-radius: 4px; padding: 12px; font-family: 'Courier New', monospace; font-size: 14px; resize: none;">${js.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</textarea>
                        </div>
                    </div>
                    
                    <!-- Footer -->
                    <div style="padding: 20px; border-top: 2px solid #34495e; display: flex; justify-content: flex-end; gap: 12px;">
                        <button id="cancel-raw-editor" style="background: #95a5a6; color: white; border: none; padding: 10px 24px; border-radius: 4px; cursor: pointer; font-size: 14px;">
                            <i class="fa fa-times"></i> Cancel
                        </button>
                        <button id="save-raw-editor" style="background: #27ae60; color: white; border: none; padding: 10px 24px; border-radius: 4px; cursor: pointer; font-size: 14px; font-weight: bold;">
                            <i class="fa fa-check"></i> Apply Changes
                        </button>
                    </div>
                </div>
            `;

            document.body.appendChild(modal);

            // Tab switching
            const tabs = modal.querySelectorAll('.raw-editor-tab');
            const contents = modal.querySelectorAll('.raw-editor-content');
            
            tabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    const targetTab = this.getAttribute('data-tab');
                    
                    // Update tab styles
                    tabs.forEach(t => {
                        t.style.background = 'transparent';
                        t.style.color = '#ecf0f1';
                    });
                    this.style.background = '#2c3e50';
                    
                    // Set color based on tab type
                    if (targetTab === 'html') {
                        this.style.color = '#e44d26'; // HTML5 orange
                    } else if (targetTab === 'css') {
                        this.style.color = '#1572b6'; // CSS3 blue
                    } else if (targetTab === 'js') {
                        this.style.color = '#f7df1e'; // JavaScript yellow
                    }
                    
                    // Show/hide content
                    contents.forEach(c => c.style.display = 'none');
                    modal.querySelector(`#${targetTab}-tab-content`).style.display = 'block';
                });
            });

            // Save button
            modal.querySelector('#save-raw-editor').addEventListener('click', () => {
                const newHtml = modal.querySelector('#raw-html-input').value;
                const newCss = modal.querySelector('#raw-css-input').value;
                const newJs = modal.querySelector('#raw-js-input').value;
                
                target.set({
                    'raw-html': newHtml,
                    'raw-css': newCss,
                    'raw-js': newJs
                });
                
                modal.remove();
            });

            // Close/Cancel buttons
            const closeModal = () => modal.remove();
            modal.querySelector('#close-raw-editor').addEventListener('click', closeModal);
            modal.querySelector('#cancel-raw-editor').addEventListener('click', closeModal);
            
            // Click outside to close
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    closeModal();
                }
            });
        }
    });

    // Accordion Button Component - Handle clicks in GrapesJS Editor
    editor.DomComponents.addType('accordion-button', {
        isComponent: el => {
            if (el && el.classList && el.classList.contains('accordion-button')) {
                return { type: 'accordion-button' };
            }
        },
        model: {
            defaults: {
                tagName: 'button',
                draggable: true,
                droppable: false,
                editable: true
            }
        },
        view: {
            events: {
                click: 'handleAccordionClick'
            },
            handleAccordionClick(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const button = this.el;
                const targetId = button.getAttribute('data-bs-target');
                if (!targetId) return;
                
                // Use the canvas document, not the main document
                const frameDoc = button.ownerDocument;
                const targetEl = frameDoc.querySelector(targetId);
                if (!targetEl) return;
                
                // Find the accordion container
                const accordion = button.closest('.accordion');
                if (!accordion) return;
                
                const isExpanded = targetEl.classList.contains('show');
                
                if (!isExpanded) {
                    // Close all other accordion items
                    accordion.querySelectorAll('.accordion-collapse').forEach(collapse => {
                        collapse.classList.remove('show');
                    });
                    accordion.querySelectorAll('.accordion-button').forEach(btn => {
                        btn.classList.add('collapsed');
                        btn.setAttribute('aria-expanded', 'false');
                    });
                    
                    // Open this item
                    targetEl.classList.add('show');
                    button.classList.remove('collapsed');
                    button.setAttribute('aria-expanded', 'true');
                    
                    // Force a repaint
                    targetEl.style.display = 'block';
                }
            }
        }
    });
    
    // Add CSS to make collapsed accordion sections visible in editor
    editor.on('load', () => {
        const canvas = editor.Canvas.getFrameEl();
        if (canvas && canvas.contentDocument) {
            const style = canvas.contentDocument.createElement('style');
            style.innerHTML = `
                /* Make all accordion sections visible in editor for easy editing */
                .gjs-dashed .accordion-collapse {
                    display: block !important;
                    height: auto !important;
                }
                .gjs-dashed .accordion-collapse.collapse:not(.show) {
                    opacity: 0.5;
                    border-left: 3px solid #999;
                }
            `;
            canvas.contentDocument.head.appendChild(style);
        }
    });

    // ========== BOOTSTRAP COLUMN COMPONENT ==========
    // Make all Bootstrap columns (col-*) droppable
    editor.DomComponents.addType('bootstrap-column', {
        isComponent: el => {
            if (el && el.tagName === 'DIV') {
                const classList = el.classList;
                if (classList) {
                    // Check if element has any col-* class
                    for (let i = 0; i < classList.length; i++) {
                        if (classList[i].startsWith('col-')) {
                            return { type: 'bootstrap-column' };
                        }
                    }
                }
            }
        },
        model: {
            defaults: {
                name: 'Column',
                draggable: '*', // Can be dragged anywhere
                droppable: true, // Can receive drops
                stylable: true,
                highlightable: true,
                copyable: true,
                removable: true,
                badgable: true
            }
        }
    });

    // ========== BOOTSTRAP ROW COMPONENT ==========
    // Make Bootstrap rows droppable
    editor.DomComponents.addType('bootstrap-row', {
        isComponent: el => {
            if (el && el.tagName === 'DIV' && el.classList && el.classList.contains('row')) {
                return { type: 'bootstrap-row' };
            }
        },
        model: {
            defaults: {
                name: 'Row',
                draggable: '*',
                droppable: true,
                stylable: true,
                highlightable: true,
                copyable: true,
                removable: true,
                badgable: true
            }
        }
    });

    console.log('✅ Custom Components: Registered (All images use Media Library + Raw HTML Component + Bootstrap Columns)');
};
