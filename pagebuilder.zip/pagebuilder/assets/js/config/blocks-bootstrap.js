/**
 * Bootstrap Blocks Library
 *
 * This file registers Bootstrap component blocks for the GrapesJS block manager.
 * Includes sections, cards, forms, buttons, and navigation components.
 */

const registerBootstrapBlocks = (editor) => {
    const bm = editor.BlockManager;

    // ========== SECTIONS ==========
    bm.add('hero-section', {
        label: `<div style="text-align:center">
                    <i class="fas fa-image" style="font-size:28px;color:#007bff;"></i>
                    <div style="font-size:11px;margin-top:5px;">Hero Section</div>
                </div>`,
        category: 'Sections',
        content: `
            <section class="hero-section py-5 bg-primary text-white">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <h1 class="display-4 fw-bold mb-4">Welcome to Our Website</h1>
                            <p class="lead mb-4">Create amazing experiences with our powerful page builder. Build professional websites in minutes.</p>
                            <a href="#" class="btn btn-light btn-lg me-2">Get Started</a>
                            <a href="#" class="btn btn-outline-light btn-lg">Learn More</a>
                        </div>
                        <div class="col-lg-6">
                            <img src="https://via.placeholder.com/600x400/4F46E5/FFFFFF?text=Hero+Image" class="img-fluid rounded shadow" alt="Hero">
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    bm.add('features-section', {
        label: `<div style="text-align:center">
                    <i class="fas fa-th-large" style="font-size:28px;color:#28a745;"></i>
                    <div style="font-size:11px;margin-top:5px;">Features Grid</div>
                </div>`,
        category: 'Sections',
        content: `
            <section class="features-section py-5">
                <div class="container">
                    <div class="text-center mb-5">
                        <h2 class="fw-bold mb-3">Our Features</h2>
                        <p class="text-muted">Discover what makes us unique</p>
                    </div>
                    <div class="row g-4">
                        <div class="col-md-4">
                            <div class="text-center p-4">
                                <div class="feature-icon bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                                    <i class="fas fa-rocket fa-2x"></i>
                                </div>
                                <h4 class="mb-3">Fast</h4>
                                <p class="text-muted">Lightning fast performance for the best user experience</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="text-center p-4">
                                <div class="feature-icon bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                                    <i class="fas fa-shield-alt fa-2x"></i>
                                </div>
                                <h4 class="mb-3">Secure</h4>
                                <p class="text-muted">Enterprise-grade security to protect your data</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="text-center p-4">
                                <div class="feature-icon bg-info text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                                    <i class="fas fa-cog fa-2x"></i>
                                </div>
                                <h4 class="mb-3">Flexible</h4>
                                <p class="text-muted">Highly customizable to fit your needs</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    bm.add('cta-section', {
        label: `<div style="text-align:center">
                    <i class="fas fa-bullhorn" style="font-size:28px;color:#ffc107;"></i>
                    <div style="font-size:11px;margin-top:5px;">Call to Action</div>
                </div>`,
        category: 'Sections',
        content: `
            <section class="cta-section py-5 bg-dark text-white text-center">
                <div class="container">
                    <h2 class="display-5 fw-bold mb-4">Ready to Get Started?</h2>
                    <p class="lead mb-4">Join thousands of satisfied customers today</p>
                    <a href="#" class="btn btn-primary btn-lg me-2">Start Free Trial</a>
                    <a href="#" class="btn btn-outline-light btn-lg">Contact Sales</a>
                </div>
            </section>
        `
    });

    // ========== CARDS ==========
    bm.add('card-basic', {
        label: `<div style="text-align:center">
                    <i class="fas fa-id-card" style="font-size:28px;color:#17a2b8;"></i>
                    <div style="font-size:11px;margin-top:5px;">Basic Card</div>
                </div>`,
        category: 'Cards',
        content: `
            <div class="card shadow-sm" style="max-width: 350px;">
                <img src="https://via.placeholder.com/350x200" class="card-img-top" alt="Card">
                <div class="card-body">
                    <h5 class="card-title">Card Title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card content.</p>
                    <a href="#" class="btn btn-primary">Learn More</a>
                </div>
            </div>
        `
    });

    bm.add('card-pricing', {
        label: `<div style="text-align:center">
                    <i class="fas fa-dollar-sign" style="font-size:28px;color:#28a745;"></i>
                    <div style="font-size:11px;margin-top:5px;">Pricing Card</div>
                </div>`,
        category: 'Cards',
        content: `
            <div class="card text-center shadow" style="max-width: 350px;">
                <div class="card-header bg-primary text-white py-3">
                    <h4 class="mb-0">Professional</h4>
                </div>
                <div class="card-body py-4">
                    <h2 class="card-title mb-0">
                        <span class="display-4 fw-bold">$29</span>
                        <span class="text-muted">/month</span>
                    </h2>
                    <ul class="list-unstyled my-4">
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>50 Projects</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>20GB Storage</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Priority Support</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Advanced Features</li>
                    </ul>
                    <button class="btn btn-primary btn-lg w-100">Get Started</button>
                </div>
            </div>
        `
    });

    // ========== FORMS ==========
    bm.add('form-contact', {
        label: `<div style="text-align:center">
                    <i class="fas fa-envelope" style="font-size:28px;color:#007bff;"></i>
                    <div style="font-size:11px;margin-top:5px;">Contact Form</div>
                </div>`,
        category: 'Forms',
        content: `
            <form class="contact-form p-4 border rounded bg-light">
                <h3 class="mb-4">Contact Us</h3>
                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control" id="name" placeholder="Your name" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" placeholder="your@email.com" required>
                </div>
                <div class="mb-3">
                    <label for="subject" class="form-label">Subject</label>
                    <input type="text" class="form-control" id="subject" placeholder="Subject">
                </div>
                <div class="mb-3">
                    <label for="message" class="form-label">Message</label>
                    <textarea class="form-control" id="message" rows="4" placeholder="Your message" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
        `
    });

    bm.add('form-newsletter', {
        label: `<div style="text-align:center">
                    <i class="fas fa-newspaper" style="font-size:28px;color:#6f42c1;"></i>
                    <div style="font-size:11px;margin-top:5px;">Newsletter Form</div>
                </div>`,
        category: 'Forms',
        content: `
            <div class="newsletter-form p-4 bg-primary text-white rounded">
                <h4 class="mb-3">Subscribe to Our Newsletter</h4>
                <p class="mb-3">Get the latest updates and offers</p>
                <form class="row g-2">
                    <div class="col-md-8">
                        <input type="email" class="form-control" placeholder="Enter your email" required>
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-light w-100">Subscribe</button>
                    </div>
                </form>
            </div>
        `
    });

    // ========== BUTTONS & ALERTS ==========
    bm.add('button-group', {
        label: `<div style="text-align:center">
                    <i class="fas fa-toggle-on" style="font-size:28px;color:#007bff;"></i>
                    <div style="font-size:11px;margin-top:5px;">Button Group</div>
                </div>`,
        category: 'Buttons',
        content: `
            <div class="btn-group" role="group">
                <button type="button" class="btn btn-primary">Primary</button>
                <button type="button" class="btn btn-secondary">Secondary</button>
                <button type="button" class="btn btn-success">Success</button>
            </div>
        `
    });

    bm.add('alert-box', {
        label: `<div style="text-align:center">
                    <i class="fas fa-exclamation-circle" style="font-size:28px;color:#ffc107;"></i>
                    <div style="font-size:11px;margin-top:5px;">Alert Box</div>
                </div>`,
        category: 'Components',
        content: `
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong>Info!</strong> This is an informational message.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `
    });

    // ========== NAVIGATION ==========
    bm.add('navbar-basic', {
        label: `<div style="text-align:center">
                    <i class="fas fa-bars" style="font-size:28px;color:#343a40;"></i>
                    <div style="font-size:11px;margin-top:5px;">Navbar</div>
                </div>`,
        category: 'Navigation',
        content: `
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <a class="navbar-brand fw-bold" href="#">Brand</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item"><a class="nav-link active" href="#">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">About</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">Services</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        `
    });

    bm.add('breadcrumb', {
        label: `<div style="text-align:center">
                    <i class="fas fa-ellipsis-h" style="font-size:28px;color:#6c757d;"></i>
                    <div style="font-size:11px;margin-top:5px;">Breadcrumb</div>
                </div>`,
        category: 'Navigation',
        content: `
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Category</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Current Page</li>
                </ol>
            </nav>
        `
    });

    // ========== LAYOUT ==========
    bm.add('container', {
        label: `<div style="text-align:center">
                    <i class="fas fa-square" style="font-size:28px;color:#20c997;"></i>
                    <div style="font-size:11px;margin-top:5px;">Container</div>
                </div>`,
        category: 'Layout',
        content: `<div class="container" style="min-height: 100px; padding: 20px;"></div>`
    });

    bm.add('row-1-col', {
        label: `<div style="text-align:center">
                    <i class="fas fa-minus" style="font-size:28px;color:#6c757d;"></i>
                    <div style="font-size:11px;margin-top:5px;">1 Column</div>
                </div>`,
        category: 'Layout',
        content: `
            <div class="row">
                <div class="col-md-12" style="padding: 20px; min-height: 100px;"></div>
            </div>
        `
    });

    bm.add('row-2-col', {
        label: `<div style="text-align:center">
                    <i class="fas fa-columns" style="font-size:28px;color:#17a2b8;"></i>
                    <div style="font-size:11px;margin-top:5px;">2 Columns</div>
                </div>`,
        category: 'Layout',
        content: `
            <div class="row">
                <div class="col-md-6" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-6" style="padding: 20px; min-height: 100px;"></div>
            </div>
        `
    });

    bm.add('row-3-col', {
        label: `<div style="text-align:center">
                    <i class="fas fa-th-large" style="font-size:28px;color:#fd7e14;"></i>
                    <div style="font-size:11px;margin-top:5px;">3 Columns</div>
                </div>`,
        category: 'Layout',
        content: `
            <div class="row">
                <div class="col-md-4" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-4" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-4" style="padding: 20px; min-height: 100px;"></div>
            </div>
        `
    });

    bm.add('row-4-col-layout', {
        label: `<div style="text-align:center">
                    <i class="fas fa-th" style="font-size:28px;color:#6f42c1;"></i>
                    <div style="font-size:11px;margin-top:5px;">4 Columns</div>
                </div>`,
        category: 'Layout',
        content: `
            <div class="row">
                <div class="col-md-3" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-3" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-3" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-3" style="padding: 20px; min-height: 100px;"></div>
            </div>
        `
    });

    bm.add('row-6-col-layout', {
        label: `<div style="text-align:center">
                    <i class="fas fa-border-all" style="font-size:28px;color:#e83e8c;"></i>
                    <div style="font-size:11px;margin-top:5px;">6 Columns</div>
                </div>`,
        category: 'Layout',
        content: `
            <div class="row">
                <div class="col-md-2" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-2" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-2" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-2" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-2" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-2" style="padding: 20px; min-height: 100px;"></div>
            </div>
        `
    });

    bm.add('row-8-col-layout', {
        label: `<div style="text-align:center">
                    <i class="fas fa-grip-horizontal" style="font-size:28px;color:#20c997;"></i>
                    <div style="font-size:11px;margin-top:5px;">8 Columns</div>
                </div>`,
        category: 'Layout',
        content: `
            <div class="row">
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
            </div>
        `
    });

    bm.add('row-12-col', {
        label: `<div style="text-align:center">
                    <i class="fas fa-grip-lines" style="font-size:28px;color:#dc3545;"></i>
                    <div style="font-size:11px;margin-top:5px;">12 Columns</div>
                </div>`,
        category: 'Layout',
        content: `
            <div class="row">
                <div class="col-md-1" style="padding: 8px; min-height: 60px; font-size: 12px;"></div>
                <div class="col-md-1" style="padding: 8px; min-height: 60px; font-size: 12px;"></div>
                <div class="col-md-1" style="padding: 8px; min-height: 60px; font-size: 12px;"></div>
                <div class="col-md-1" style="padding: 8px; min-height: 60px; font-size: 12px;"></div>
                <div class="col-md-1" style="padding: 8px; min-height: 60px; font-size: 12px;"></div>
                <div class="col-md-1" style="padding: 8px; min-height: 60px; font-size: 12px;"></div>
                <div class="col-md-1" style="padding: 8px; min-height: 60px; font-size: 12px;"></div>
                <div class="col-md-1" style="padding: 8px; min-height: 60px; font-size: 12px;"></div>
                <div class="col-md-1" style="padding: 8px; min-height: 60px; font-size: 12px;"></div>
                <div class="col-md-1" style="padding: 8px; min-height: 60px; font-size: 12px;"></div>
                <div class="col-md-1" style="padding: 8px; min-height: 60px; font-size: 12px;"></div>
                <div class="col-md-1" style="padding: 8px; min-height: 60px; font-size: 12px;"></div>
            </div>
        `
    });

    bm.add('row-4-col', {
        label: `<div style="text-align:center">
                    <i class="fas fa-th" style="font-size:28px;color:#6f42c1;"></i>
                    <div style="font-size:11px;margin-top:5px;">4 Columns</div>
                </div>`,
        category: 'Basic',
        content: `
            <div class="row">
                <div class="col-md-3" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-3" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-3" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-3" style="padding: 20px; min-height: 100px;"></div>
            </div>
        `
    });

    bm.add('row-6-col', {
        label: `<div style="text-align:center">
                    <i class="fas fa-border-all" style="font-size:28px;color:#e83e8c;"></i>
                    <div style="font-size:11px;margin-top:5px;">6 Columns</div>
                </div>`,
        category: 'Basic',
        content: `
            <div class="row">
                <div class="col-md-2" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-2" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-2" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-2" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-2" style="padding: 20px; min-height: 100px;"></div>
                <div class="col-md-2" style="padding: 20px; min-height: 100px;"></div>
            </div>
        `
    });

    bm.add('row-8-col', {
        label: `<div style="text-align:center">
                    <i class="fas fa-grip-horizontal" style="font-size:28px;color:#20c997;"></i>
                    <div style="font-size:11px;margin-top:5px;">8 Columns</div>
                </div>`,
        category: 'Basic',
        content: `
            <div class="row">
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
                <div class="col-md-1p5" style="padding: 10px; min-height: 80px; flex: 0 0 12.5%; max-width: 12.5%;"></div>
            </div>
        `
    });

    console.log('Bootstrap Blocks: Registered (Layout: 1-12 columns, Basic: 4,6,8 columns)');
};
