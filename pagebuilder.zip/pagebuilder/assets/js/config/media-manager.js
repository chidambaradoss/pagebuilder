/**
 * Media Manager for GrapesJS
 *
 * This file handles the custom media library modal with upload functionality,
 * image browsing, and selection.
 */

const setupMediaManager = (editor) => {
    let currentTarget = null;
    let selectionMode = 'src'; // Can be 'src' or 'background'

    // Add command to open media library
    editor.Commands.add('open-media-library', {
        run(editor, sender, options = {}) {
            // First, stop the command to ensure clean state
            if (editor.Commands.isActive('open-media-library')) {
                console.log('Command already active, stopping first...');
                editor.stopCommand('open-media-library');
                // Small delay to allow proper cleanup
                setTimeout(() => {
                    this.run(editor, sender, options);
                }, 50);
                return;
            }
            
            currentTarget = options.target || editor.getSelected();
            selectionMode = options.mode || 'src'; // 'src' for img elements, 'background' for div backgrounds
            
            console.log('Opening media library:', { selectionMode, currentTarget, tagName: currentTarget?.get('tagName') });
            
            showMediaPopup();
        },
        stop(editor) {
            currentTarget = null;
            console.log('Command stopped, closing modal');
            editor.Modal.close();
        }
    });

    // Create and show media popup
    const showMediaPopup = () => {
        const modal = editor.Modal;
        const modalTitle = selectionMode === 'background' ? 
            'Select Background Image' : 
            'Media Library';
        modal.setTitle(modalTitle);

        const modalContent = `
            <div class="media-library-container">
                <div class="media-library-tabs">
                    <button class="tab-btn active" data-tab="library">
                        <i class="fa fa-images"></i> Media Library
                    </button>
                    <button class="tab-btn" data-tab="upload">
                        <i class="fa fa-upload"></i> Upload New
                    </button>
                </div>

                <div class="media-library-content">
                    <!-- Library Tab -->
                    <div class="tab-content active" id="library-tab">
                        <div class="media-search">
                            <input type="text" id="media-search-input" placeholder="Search media files..." class="form-control">
                        </div>
                        <div class="media-grid" id="media-grid">
                            <div class="loading">
                                <i class="fa fa-spinner fa-spin fa-2x"></i>
                                <p>Loading media files...</p>
                            </div>
                        </div>
                    </div>

                    <!-- Upload Tab -->
                    <div class="tab-content" id="upload-tab">
                        <div class="upload-area" id="upload-area">
                            <i class="fa fa-cloud-upload-alt fa-3x"></i>
                            <p>Drag and drop images here or click to browse</p>
                            <p class="text-muted small">Supported formats: JPG, PNG, GIF, WebP (Max 5MB)</p>
                            <input type="file" id="file-input" accept="image/*" multiple style="display:none">
                            <button id="browse-btn" class="btn btn-primary mt-3">
                                <i class="fa fa-folder-open"></i> Browse Files
                            </button>
                        </div>
                        <div class="upload-progress" id="upload-progress" style="display:none">
                            <div class="progress">
                                <div class="progress-bar" id="progress-bar" style="width: 0%"></div>
                            </div>
                            <p id="upload-status">Uploading...</p>
                        </div>
                    </div>
                </div>

                <div class="media-library-footer">
                    <button class="btn btn-secondary" id="cancel-media">Cancel</button>
                    <button class="btn btn-primary" id="select-media" disabled>Select Image</button>
                </div>
            </div>
        `;

        modal.setContent(modalContent);
        
        modal.open();
        
        console.log('Modal opened, setting up listeners...');
        
        // Listen for modal close to stop the command
        const modalEl = modal.getContentEl()?.closest('.gjs-mdl-container');
        if (modalEl) {
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    if (mutation.attributeName === 'style') {
                        const display = modalEl.style.display;
                        if (display === 'none' || display === '') {
                            console.log('Modal hidden detected, stopping command');
                            observer.disconnect();
                            editor.stopCommand('open-media-library');
                            currentTarget = null;
                        }
                    }
                });
            });
            
            observer.observe(modalEl, { attributes: true, attributeFilter: ['style'] });
        }
        
        // Wait for DOM to be ready, then setup
        setTimeout(() => {
            // Load media files
            loadMediaFiles();

            // Setup event listeners (only once per modal open)
            setupMediaListeners();
        }, 50);
    };

    // Load media files from API
    const loadMediaFiles = () => {
        fetch(window.PAGEBUILDER_CONFIG.apiEndpoints.media)
            .then(response => response.json())
            .then(data => {
                console.log('Media files loaded:', data);
                if (data.success) {
                    renderMediaGrid(data.files);
                } else {
                    document.getElementById('media-grid').innerHTML = `
                        <div class="error">
                            <i class="fa fa-exclamation-triangle fa-2x"></i>
                            <p>Failed to load media files</p>
                        </div>
                    `;
                }
            })
            .catch(error => {
                console.error('Error loading media:', error);
                document.getElementById('media-grid').innerHTML = `
                    <div class="error">
                        <i class="fa fa-exclamation-triangle fa-2x"></i>
                        <p>Error loading media files</p>
                    </div>
                `;
            });
    };

    // Render media grid
    const renderMediaGrid = (files) => {
        const grid = document.getElementById('media-grid');

        if (!files || files.length === 0) {
            grid.innerHTML = `
                <div class="no-media">
                    <i class="fa fa-image fa-3x"></i>
                    <p>No media files found</p>
                    <p class="text-muted">Upload some images to get started</p>
                </div>
            `;
            return;
        }

        grid.innerHTML = files.map(file => `
            <div class="media-item" data-url="${file.url}" data-id="${file.id}" title="${file.name}">
                <img src="${file.thumbnail}" alt="${file.name}" loading="lazy">
                <div class="media-info">
                    <span class="media-name">${file.name}</span>
                    <span class="media-size">${file.size}</span>
                    <span class="media-dimensions">${file.dimensions}</span>
                </div>
            </div>
        `).join('');

        // Add click handlers
        document.querySelectorAll('.media-item').forEach(item => {
            item.addEventListener('click', function() {
                document.querySelectorAll('.media-item').forEach(i =>
                    i.classList.remove('selected'));
                this.classList.add('selected');
                document.getElementById('select-media').disabled = false;
            });
        });
    };

    // Setup media library event listeners
    const setupMediaListeners = () => {
        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const tab = this.dataset.tab;
                document.querySelectorAll('.tab-btn').forEach(b =>
                    b.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c =>
                    c.classList.remove('active'));
                this.classList.add('active');
                document.getElementById(tab + '-tab').classList.add('active');
            });
        });

        // Upload area
        const uploadArea = document.getElementById('upload-area');
        const fileInput = document.getElementById('file-input');
        const browseBtn = document.getElementById('browse-btn');

        if (browseBtn) {
            browseBtn.addEventListener('click', () => fileInput.click());
        }

        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                handleFileUpload(e.target.files);
            });
        }

        // Drag and drop
        if (uploadArea) {
            uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadArea.classList.add('dragover');
            });

            uploadArea.addEventListener('dragleave', () => {
                uploadArea.classList.remove('dragover');
            });

            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                handleFileUpload(e.dataTransfer.files);
            });
        }

        // Search
        const searchInput = document.getElementById('media-search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                const searchTerm = e.target.value.toLowerCase();
                document.querySelectorAll('.media-item').forEach(item => {
                    const name = item.querySelector('.media-name').textContent.toLowerCase();
                    item.style.display = name.includes(searchTerm) ? 'block' : 'none';
                });
            });
        }

        // Select button
        const selectBtn = document.getElementById('select-media');
        if (selectBtn) {
            selectBtn.addEventListener('click', () => {
                const selected = document.querySelector('.media-item.selected');
                if (selected && currentTarget) {
                    const imageUrl = selected.dataset.url;
                    
                    console.log('Image selected:', { imageUrl, selectionMode, target: currentTarget.get('tagName') });
                    
                    if (selectionMode === 'background') {
                        // Set as background image
                        currentTarget.setStyle({
                            'background-image': `url('${imageUrl}')`,
                            'background-size': 'cover',
                            'background-position': 'center',
                            'background-repeat': 'no-repeat'
                        });
                        console.log('✅ Background image applied:', imageUrl);
                    } else {
                        // Set as src attribute (for img elements)
                        currentTarget.set('src', imageUrl);
                        console.log('✅ Image src applied:', imageUrl);
                    }
                    
                    // Reset, close modal and stop command
                    currentTarget = null;
                    editor.Modal.close();
                    setTimeout(() => {
                        editor.stopCommand('open-media-library');
                    }, 100);
                    console.log('Modal closed after selection');
                }
            });
        }

        // Cancel button
        const cancelBtn = document.getElementById('cancel-media');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                console.log('Cancel clicked, closing modal');
                currentTarget = null;
                editor.Modal.close();
                setTimeout(() => {
                    editor.stopCommand('open-media-library');
                }, 100);
            });
        }
    };

    // Handle file upload
    const handleFileUpload = (files) => {
        if (!files || files.length === 0) return;

        const formData = new FormData();
        Array.from(files).forEach(file => {
            formData.append('images[]', file);
        });

        const progressBar = document.getElementById('progress-bar');
        const progressContainer = document.getElementById('upload-progress');
        const uploadStatus = document.getElementById('upload-status');
        const uploadArea = document.getElementById('upload-area');

        uploadArea.style.display = 'none';
        progressContainer.style.display = 'block';

        const xhr = new XMLHttpRequest();

        // Progress event
        xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
                const percentComplete = (e.loaded / e.total) * 100;
                progressBar.style.width = percentComplete + '%';
                uploadStatus.textContent = `Uploading... ${Math.round(percentComplete)}%`;
            }
        });

        // Load event
        xhr.addEventListener('load', () => {
            if (xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    console.log('Upload response:', response);

                    if (response.success) {
                        uploadStatus.textContent = 'Upload complete!';
                        uploadStatus.className = 'text-success';

                        // Show errors if any
                        if (response.errors && response.errors.length > 0) {
                            alert('Some files failed:\n' + response.errors.join('\n'));
                        }

                        setTimeout(() => {
                            // Switch to library tab and reload
                            document.querySelector('[data-tab="library"]').click();
                            loadMediaFiles();
                            uploadArea.style.display = 'block';
                            progressContainer.style.display = 'none';
                            progressBar.style.width = '0%';
                            uploadStatus.className = '';
                            document.getElementById('file-input').value = '';
                        }, 1000);
                    } else {
                        uploadStatus.textContent = 'Upload failed: ' + (response.message || 'Unknown error');
                        uploadStatus.className = 'text-danger';
                    }
                } catch (error) {
                    console.error('Parse error:', error);
                    uploadStatus.textContent = 'Upload failed: Invalid response';
                    uploadStatus.className = 'text-danger';
                }
            } else {
                uploadStatus.textContent = 'Upload failed with status: ' + xhr.status;
                uploadStatus.className = 'text-danger';
            }
        });

        // Error event
        xhr.addEventListener('error', () => {
            uploadStatus.textContent = 'Upload failed. Please try again.';
            uploadStatus.className = 'text-danger';
        });

        xhr.open('POST', window.PAGEBUILDER_CONFIG.apiEndpoints.upload);
        xhr.send(formData);
    };

    console.log('Media Manager: Loaded');
};
