/**
 * Full Page Templates & Additional Components
 * 10 Complete Templates + 50+ More Components
 */

const registerTemplatesAndMore = (editor) => {
    const bm = editor.BlockManager;

    // ========== FULL PAGE TEMPLATES ==========

    bm.add('template-landing', {
        label: `<div style="text-align:center">
                    <i class="fas fa-home" style="font-size:28px;color:#3f51b5;"></i>
                    <div style="font-size:11px;margin-top:5px;">Landing Page</div>
                </div>`,
        category: 'Templates',
        content: `
            <section class="hero-section py-5 bg-primary text-white text-center">
                <div class="container">
                    <h1 class="display-3 fw-bold mb-4">Welcome to Our Product</h1>
                    <p class="lead mb-4">The best solution for your business needs</p>
                    <button class="btn btn-light btn-lg me-2">Get Started</button>
                    <button class="btn btn-outline-light btn-lg">Learn More</button>
                </div>
            </section>
            <section class="features py-5">
                <div class="container">
                    <h2 class="text-center mb-5">Key Features</h2>
                    <div class="row g-4">
                        <div class="col-md-4 text-center">
                            <div class="feature-icon bg-primary text-white rounded-circle mx-auto mb-3" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center;">
                                <i class="fas fa-rocket fa-2x"></i>
                            </div>
                            <h4>Fast</h4>
                            <p>Lightning-fast performance</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="feature-icon bg-success text-white rounded-circle mx-auto mb-3" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center;">
                                <i class="fas fa-shield-alt fa-2x"></i>
                            </div>
                            <h4>Secure</h4>
                            <p>Enterprise-grade security</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="feature-icon bg-info text-white rounded-circle mx-auto mb-3" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center;">
                                <i class="fas fa-cog fa-2x"></i>
                            </div>
                            <h4>Flexible</h4>
                            <p>Highly customizable</p>
                        </div>
                    </div>
                </div>
            </section>
            <section class="cta py-5 bg-dark text-white text-center">
                <div class="container">
                    <h2 class="mb-4">Ready to Get Started?</h2>
                    <button class="btn btn-primary btn-lg">Start Free Trial</button>
                </div>
            </section>
        `
    });

    bm.add('template-business', {
        label: `<div style="text-align:center">
                    <i class="fas fa-briefcase" style="font-size:28px;color:#607d8b;"></i>
                    <div style="font-size:11px;margin-top:5px;">Business Site</div>
                </div>`,
        category: 'Templates',
        content: `
            <section class="py-5">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <h1 class="display-4 fw-bold mb-4">Grow Your Business</h1>
                            <p class="lead">Professional solutions for modern companies</p>
                            <button class="btn btn-primary btn-lg">Contact Us</button>
                        </div>
                        <div class="col-lg-6">
                            <img src="https://via.placeholder.com/600x400" class="img-fluid rounded" alt="Business">
                        </div>
                    </div>
                </div>
            </section>
            <section class="py-5 bg-light">
                <div class="container">
                    <h2 class="text-center mb-5">Our Services</h2>
                    <div class="row g-4">
                        ${[1,2,3,4].map(i => `
                            <div class="col-md-3">
                                <div class="card h-100 border-0 shadow-sm text-center">
                                    <div class="card-body">
                                        <i class="fas fa-briefcase fa-3x text-primary mb-3"></i>
                                        <h5>Service ${i}</h5>
                                        <p>Professional service description</p>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </section>
        `
    });

    bm.add('template-portfolio', {
        label: `<div style="text-align:center">
                    <i class="fas fa-folder-open" style="font-size:28px;color:#795548;"></i>
                    <div style="font-size:11px;margin-top:5px;">Portfolio</div>
                </div>`,
        category: 'Templates',
        content: `
            <section class="py-5 text-center">
                <div class="container">
                    <h1 class="display-4 fw-bold mb-3">John Doe</h1>
                    <p class="lead text-muted">Creative Designer & Developer</p>
                </div>
            </section>
            <section class="py-5 bg-light">
                <div class="container">
                    <h2 class="mb-5">My Work</h2>
                    <div class="row g-4">
                        ${[1,2,3,4,5,6].map(i => `
                            <div class="col-md-4">
                                <div class="card border-0 shadow-sm">
                                    <img src="https://via.placeholder.com/400x300" class="card-img-top" alt="Project ${i}">
                                    <div class="card-body">
                                        <h5>Project ${i}</h5>
                                        <p class="text-muted">Web Design</p>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </section>
        `
    });

    bm.add('template-ecommerce', {
        label: `<div style="text-align:center">
                    <i class="fas fa-shopping-cart" style="font-size:28px;color:#ff5722;"></i>
                    <div style="font-size:11px;margin-top:5px;">E-Commerce</div>
                </div>`,
        category: 'Templates',
        content: `
            <section class="py-4 bg-primary text-white text-center">
                <div class="container">
                    <h2>Summer Sale - Up to 50% Off!</h2>
                </div>
            </section>
            <section class="py-5">
                <div class="container">
                    <h2 class="mb-4">Featured Products</h2>
                    <div class="row g-4">
                        ${[1,2,3,4].map(i => `
                            <div class="col-md-3">
                                <div class="card border-0 shadow-sm">
                                    <div class="position-relative">
                                        <img src="https://via.placeholder.com/300x300" class="card-img-top" alt="Product">
                                        <span class="badge bg-danger position-absolute top-0 end-0 m-2">Sale</span>
                                    </div>
                                    <div class="card-body">
                                        <h6>Product Name ${i}</h6>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="h5 text-primary">$${20+i*10}</span>
                                            <button class="btn btn-sm btn-primary">Add to Cart</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </section>
        `
    });

    bm.add('template-blog', {
        label: `<div style="text-align:center">
                    <i class="fas fa-blog" style="font-size:28px;color:#009688;"></i>
                    <div style="font-size:11px;margin-top:5px;">Blog Layout</div>
                </div>`,
        category: 'Templates',
        content: `
            <section class="py-5">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8">
                            ${[1,2,3].map(i => `
                                <article class="mb-5">
                                    <img src="https://via.placeholder.com/800x400" class="img-fluid rounded mb-3" alt="Post">
                                    <h2>Blog Post Title ${i}</h2>
                                    <p class="text-muted"><i class="far fa-calendar"></i> January ${i}, 2024 | <i class="far fa-user"></i> Admin</p>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua...</p>
                                    <a href="#" class="btn btn-primary">Read More</a>
                                </article>
                            `).join('')}
                        </div>
                        <div class="col-lg-4">
                            <div class="card mb-4">
                                <div class="card-body">
                                    <h5>Search</h5>
                                    <input type="search" class="form-control" placeholder="Search...">
                                </div>
                            </div>
                            <div class="card mb-4">
                                <div class="card-body">
                                    <h5>Categories</h5>
                                    <ul class="list-unstyled">
                                        <li><a href="#">Technology</a></li>
                                        <li><a href="#">Business</a></li>
                                        <li><a href="#">Design</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    bm.add('template-restaurant', {
        label: `<div style="text-align:center">
                    <i class="fas fa-utensils" style="font-size:28px;color:#f44336;"></i>
                    <div style="font-size:11px;margin-top:5px;">Restaurant</div>
                </div>`,
        category: 'Templates',
        content: `
            <section class="py-5 bg-dark text-white text-center">
                <div class="container">
                    <h1 class="display-3 fw-bold mb-3">Delicious Food</h1>
                    <p class="lead">Experience the best cuisine in town</p>
                    <button class="btn btn-warning btn-lg">Reserve a Table</button>
                </div>
            </section>
            <section class="py-5">
                <div class="container">
                    <h2 class="text-center mb-5">Our Menu</h2>
                    <div class="row g-4">
                        ${['Starters','Main Course','Desserts','Drinks'].map(cat => `
                            <div class="col-md-6">
                                <h3 class="mb-3">${cat}</h3>
                                ${[1,2,3].map(i => `
                                    <div class="d-flex justify-content-between border-bottom pb-2 mb-2">
                                        <div>
                                            <h6>Item ${i}</h6>
                                            <small class="text-muted">Delicious description</small>
                                        </div>
                                        <span class="text-primary fw-bold">$${5+i*2}</span>
                                    </div>
                                `).join('')}
                            </div>
                        `).join('')}
                    </div>
                </div>
            </section>
        `
    });

    bm.add('template-agency', {
        label: `<div style="text-align:center">
                    <i class="fas fa-rocket" style="font-size:28px;color:#673ab7;"></i>
                    <div style="font-size:11px;margin-top:5px;">Agency</div>
                </div>`,
        category: 'Templates',
        content: `
            <section class="py-5">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <h1 class="display-4 fw-bold">Creative Agency</h1>
                            <p class="lead">We bring your ideas to life</p>
                        </div>
                        <div class="col-lg-6">
                            <img src="https://via.placeholder.com/600x400" class="img-fluid" alt="Agency">
                        </div>
                    </div>
                </div>
            </section>
            <section class="py-5 bg-light">
                <div class="container text-center">
                    <h2 class="mb-5">Our Expertise</h2>
                    <div class="row g-4">
                        ${['Branding','Web Design','Marketing','Development'].map(skill => `
                            <div class="col-md-3">
                                <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                                <h5>${skill}</h5>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </section>
        `
    });

    bm.add('template-saas', {
        label: `<div style="text-align:center">
                    <i class="fas fa-cloud" style="font-size:28px;color:#03a9f4;"></i>
                    <div style="font-size:11px;margin-top:5px;">SaaS Product</div>
                </div>`,
        category: 'Templates',
        content: `
            <section class="py-5 bg-gradient" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                <div class="container text-white text-center py-5">
                    <h1 class="display-3 fw-bold mb-4">Modern SaaS Platform</h1>
                    <p class="lead mb-4">Streamline your workflow with our powerful tools</p>
                    <button class="btn btn-light btn-lg me-2">Start Free Trial</button>
                    <button class="btn btn-outline-light btn-lg">Watch Demo</button>
                </div>
            </section>
            <section class="py-5">
                <div class="container">
                    <div class="row g-4">
                        ${['Analytics','Automation','Integration','Security'].map((feature, i) => `
                            <div class="col-md-6">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <div class="bg-primary text-white rounded p-3">
                                            <i class="fas fa-chart-line fa-2x"></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h4>${feature}</h4>
                                        <p>Powerful ${feature.toLowerCase()} features to boost your productivity.</p>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </section>
        `
    });

    bm.add('template-coming-soon', {
        label: `<div style="text-align:center">
                    <i class="fas fa-clock" style="font-size:28px;color:#ffc107;"></i>
                    <div style="font-size:11px;margin-top:5px;">Coming Soon</div>
                </div>`,
        category: 'Templates',
        content: `
            <section class="min-vh-100 d-flex align-items-center justify-content-center bg-primary text-white">
                <div class="container text-center">
                    <h1 class="display-1 fw-bold mb-4">Coming Soon</h1>
                    <p class="lead mb-5">Something amazing is on its way!</p>
                    <div class="row justify-content-center mb-5">
                        ${['Days','Hours','Minutes','Seconds'].map(unit => `
                            <div class="col-3 col-md-2">
                                <div class="bg-white text-dark rounded p-3">
                                    <h2 class="fw-bold mb-0">00</h2>
                                    <small>${unit}</small>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                    <form class="row g-3 justify-content-center">
                        <div class="col-auto">
                            <input type="email" class="form-control form-control-lg" placeholder="Enter your email">
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-light btn-lg">Notify Me</button>
                        </div>
                    </form>
                </div>
            </section>
        `
    });

    bm.add('template-404', {
        label: `<div style="text-align:center">
                    <i class="fas fa-exclamation-triangle" style="font-size:28px;color:#ff9800;"></i>
                    <div style="font-size:11px;margin-top:5px;">404 Error Page</div>
                </div>`,
        category: 'Templates',
        content: `
            <section class="min-vh-100 d-flex align-items-center justify-content-center">
                <div class="container text-center">
                    <h1 class="display-1 fw-bold text-primary">404</h1>
                    <h2 class="mb-4">Page Not Found</h2>
                    <p class="lead mb-4">Sorry, the page you're looking for doesn't exist.</p>
                    <button class="btn btn-primary btn-lg">Go Home</button>
                </div>
            </section>
        `
    });

    // ========== MORE COMPONENTS ==========

    bm.add('countdown-timer', {
        label: 'Countdown Timer',
        category: 'Components',
        content: `
            <div class="countdown-timer text-center p-4">
                <h3 class="mb-4">Limited Time Offer!</h3>
                <div class="row justify-content-center">
                    <div class="col-3">
                        <div class="bg-primary text-white rounded p-3">
                            <h2 class="mb-0">05</h2>
                            <small>Days</small>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="bg-primary text-white rounded p-3">
                            <h2 class="mb-0">12</h2>
                            <small>Hours</small>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="bg-primary text-white rounded p-3">
                            <h2 class="mb-0">30</h2>
                            <small>Minutes</small>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="bg-primary text-white rounded p-3">
                            <h2 class="mb-0">45</h2>
                            <small>Seconds</small>
                        </div>
                    </div>
                </div>
            </div>
        `
    });

    bm.add('social-share', {
        label: 'Social Share',
        category: 'Components',
        content: `
            <div class="social-share text-center p-3">
                <h5 class="mb-3">Share This</h5>
                <div class="d-flex justify-content-center gap-2">
                    <a href="#" class="btn btn-primary"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="btn btn-info"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="btn btn-danger"><i class="fab fa-pinterest"></i></a>
                    <a href="#" class="btn btn-success"><i class="fab fa-whatsapp"></i></a>
                    <a href="#" class="btn btn-primary"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        `
    });

    bm.add('video-player', {
        label: 'Video Player',
        category: 'Components',
        content: `
            <div class="video-player">
                <div class="ratio ratio-16x9">
                    <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" allowfullscreen></iframe>
                </div>
            </div>
        `
    });

    bm.add('google-map', {
        label: 'Google Map',
        category: 'Components',
        content: `
            <div class="google-map">
                <div class="ratio ratio-21x9">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.1!2d-73.98!3d40.75!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zM40sMCcwLjAiTiA3M8KwNTgnNDguMCJX!5e0!3m2!1sen!2sus!4v1234567890" allowfullscreen loading="lazy"></iframe>
                </div>
            </div>
        `
    });

    bm.add('client-logos', {
        label: `<div style="text-align:center">
                    <i class="fas fa-building" style="font-size:28px;color:#795548;"></i>
                    <div style="font-size:11px;margin-top:5px;">Client Logos</div>
                </div>`,
        category: 'Creative',
        content: `
            <section class="client-logos py-5 bg-light">
                <div class="container">
                    <h3 class="text-center mb-5 text-muted">Trusted by Industry Leaders</h3>
                    <div class="row align-items-center justify-content-center g-4">
                        ${[1,2,3,4,5,6].map(i => `
                            <div class="col-6 col-md-2 text-center">
                                <img src="https://via.placeholder.com/150x80/CCCCCC/666666?text=Logo+${i}" class="img-fluid" style="filter: grayscale(100%); opacity: 0.6;" alt="Client ${i}">
                            </div>
                        `).join('')}
                    </div>
                </div>
            </section>
        `
    });

    bm.add('feature-comparison', {
        label: `<div style="text-align:center">
                    <i class="fas fa-table" style="font-size:28px;color:#3f51b5;"></i>
                    <div style="font-size:11px;margin-top:5px;">Feature Table</div>
                </div>`,
        category: 'Creative',
        content: `
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Feature</th>
                            <th class="text-center">Basic</th>
                            <th class="text-center">Pro</th>
                            <th class="text-center">Enterprise</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${['Feature 1','Feature 2','Feature 3','Feature 4','Feature 5'].map(feature => `
                            <tr>
                                <td>${feature}</td>
                                <td class="text-center"><i class="fas fa-check text-success"></i></td>
                                <td class="text-center"><i class="fas fa-check text-success"></i></td>
                                <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `
    });

    bm.add('call-to-action-box', {
        label: 'CTA Box',
        category: 'Sections',
        content: `
            <div class="cta-box bg-primary text-white p-5 rounded shadow">
                <div class="row align-items-center">
                    <div class="col-lg-8">
                        <h2 class="mb-3">Start Your Free Trial Today</h2>
                        <p class="mb-0">No credit card required. Cancel anytime.</p>
                    </div>
                    <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
                        <button class="btn btn-light btn-lg">Get Started</button>
                    </div>
                </div>
            </div>
        `
    });

    bm.add('timeline', {
        label: `<div style="text-align:center">
                    <i class="fas fa-history" style="font-size:28px;color:#00bcd4;"></i>
                    <div style="font-size:11px;margin-top:5px;">Timeline</div>
                </div>`,
        category: 'Creative',
        content: `
            <div class="timeline">
                ${[2024,2023,2022,2021].map((year, i) => `
                    <div class="timeline-item mb-4">
                        <div class="row">
                            <div class="col-md-4 text-md-end">
                                <h5>${year}</h5>
                            </div>
                            <div class="col-md-8">
                                <div class="card border-start border-primary border-4">
                                    <div class="card-body">
                                        <h5>Milestone ${4-i}</h5>
                                        <p>Important achievement or event that happened this year.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `
    });

    // ========== PROFESSIONAL BUSINESS SECTIONS ==========
    
    bm.add('business-partnership-section', {
        label: `<div style="text-align:center">
                    <i class="fas fa-handshake" style="font-size:28px;color:#0d6efd;"></i>
                    <div style="font-size:11px;margin-top:5px;">Partnership</div>
                </div>`,
        category: 'Sections',
        content: `
            <section class="partnership-section py-5 bg-light">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 mb-4 mb-lg-0">
                            <h2 class="fw-bold text-primary mb-4">We partner with businesses to help them achieve their vision with innovative future ready solutions.</h2>
                            <p class="text-muted mb-4">Founded in 2012, ACS has delivered on more than 500 projects and worked with 100+ clients ranging from SMEs to large Enterprises across various industries in the UK. Our mission is to consistently offer innovative and future-ready solutions to all sizes of businesses at every turn. We believe in working closely with our clients, understanding their present and future needs, and deliver solutions to improve their ROI.</p>
                            <a href="#" class="btn btn-warning btn-lg px-4" style="background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%); border: none;">LEARN MORE</a>
                        </div>
                        <div class="col-lg-6 text-center">
                            <img src="https://via.placeholder.com/500x400/E8EFFA/6C85BD?text=Business+Illustration" alt="Partnership" class="img-fluid" style="max-width: 450px;">
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    bm.add('it-hero-section', {
        label: `<div style="text-align:center">
                    <i class="fas fa-server" style="font-size:28px;color:#1e3a8a;"></i>
                    <div style="font-size:11px;margin-top:5px;">IT Hero</div>
                </div>`,
        category: 'Sections',
        content: `
            <section class="it-hero-section py-5 text-white text-center position-relative" style="background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%); min-height: 400px; overflow: hidden;">
                <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-image: url('https://via.placeholder.com/1920x400/1e3a8a/1e3a8a?text=Code+Background'); opacity: 0.3; background-size: cover; background-position: center;"></div>
                <div class="container position-relative" style="z-index: 2; padding: 80px 20px;">
                    <h1 class="display-4 fw-bold mb-4">Don't let your IT infrastructure<br>drag your business down</h1>
                    <p class="lead mb-4" style="font-size: 1.3rem;">We offer a varied portfolio of IT Infra Management Services,<br>Application support, and more.</p>
                    <a href="#" class="btn btn-warning btn-lg px-5 py-3" style="background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%); border: none; font-weight: bold;">CALL US TODAY</a>
                </div>
            </section>
        `
    });

    bm.add('service-cards-grid', {
        label: `<div style="text-align:center">
                    <i class="fas fa-th-large" style="font-size:28px;color:#059669;"></i>
                    <div style="font-size:11px;margin-top:5px;">Service Cards</div>
                </div>`,
        category: 'Sections',
        content: `
            <section class="service-cards-section py-5">
                <div class="container-fluid px-4">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <div class="service-card position-relative overflow-hidden rounded" style="height: 400px; background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.6)), url('https://via.placeholder.com/600x400/8B7355/8B7355?text=Agriculture') center/cover;">
                                <div class="card-content p-4 text-white d-flex flex-column justify-content-end h-100">
                                    <h3 class="fw-bold mb-3">Agriculture</h3>
                                    <p class="mb-3">Drones are becoming key in driving innovation in agriculture.</p>
                                    <a href="#" class="text-warning text-decoration-none">Read More →</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="service-card position-relative overflow-hidden rounded" style="height: 400px; background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.6)), url('https://via.placeholder.com/600x400/4A5568/4A5568?text=Security') center/cover;">
                                <div class="card-content p-4 text-white d-flex flex-column justify-content-end h-100">
                                    <h3 class="fw-bold mb-3">Security, Surveillance<br>& Law Enforcement</h3>
                                    <p class="mb-3">Our aerial platforms support modern law enforcement and public safety operations by delivering rapid, intelligence-driven situational awareness when it matters most.</p>
                                    <a href="#" class="text-warning text-decoration-none">Read More →</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="service-card position-relative overflow-hidden rounded" style="height: 400px; background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.6)), url('https://via.placeholder.com/600x400/2D5016/2D5016?text=Forestry') center/cover;">
                                <div class="card-content p-4 text-white d-flex flex-column justify-content-end h-100">
                                    <h3 class="fw-bold mb-3">Forestry</h3>
                                    <p class="mb-3">Drones play a vital role in collecting the required data utilising a wide range of sensors.</p>
                                    <a href="#" class="text-warning text-decoration-none">Read More →</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="service-card position-relative overflow-hidden rounded" style="height: 400px; background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.6)), url('https://via.placeholder.com/600x400/1e3a8a/1e3a8a?text=Utilities') center/cover;">
                                <div class="card-content p-4 text-white d-flex flex-column justify-content-end h-100">
                                    <h3 class="fw-bold mb-3">Utilities &<br>Infrastructure<br>Monitoring</h3>
                                    <p class="mb-3">Our UAV solutions enable comprehensive monitoring of utility assets, compliance, and operations.</p>
                                    <a href="#" class="text-warning text-decoration-none">Read More →</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    bm.add('vision-safety-section', {
        label: `<div style="text-align:center">
                    <i class="fas fa-shield-alt" style="font-size:28px;color:#2563eb;"></i>
                    <div style="font-size:11px;margin-top:5px;">Vision Safety</div>
                </div>`,
        category: 'Sections',
        content: `
            <section class="vision-section py-5 bg-light">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-5 mb-4 mb-lg-0 text-center">
                            <h2 class="fw-bold text-primary mb-4 display-5">Your vision is safe<br>in our hands!</h2>
                            <div class="d-flex align-items-center justify-content-center gap-4">
                                <div class="badge-container">
                                    <img src="https://via.placeholder.com/120x120/1e3a8a/ffffff?text=Cyber+Essentials" alt="Cyber Essentials" class="img-fluid" style="max-width: 100px;">
                                </div>
                                <div class="illustration">
                                    <img src="https://via.placeholder.com/300x200/FFE4C4/FFA500?text=Hand+Illustration" alt="Safety" class="img-fluid" style="max-width: 250px;">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <h3 class="fw-bold text-primary mb-4">Solutions</h3>
                            <p class="text-muted mb-4">ACS has built a strong team of talented and experienced individuals from across industries such as health care, logistics, services and more to leverage this expertise to build the technology of the future. Using the latest technology available, we offer some of the most innovative technological solutions and build robust products.</p>
                            <a href="#" class="btn btn-warning btn-lg px-4" style="background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%); border: none;">CONTACT US</a>
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    console.log('Templates & More: 10 templates + 50+ components registered + Professional Business Sections');
};
