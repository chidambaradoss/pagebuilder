/**
 * Extended Blocks Library - 50+ Additional Components
 */

const registerExtendedBlocks = (editor) => {
    const bm = editor.BlockManager;

    // ========== MORE SECTIONS ==========
    bm.add('about-section', {
        label: `<div style="text-align:center">
                    <i class="fas fa-info-circle" style="font-size:28px;color:#6f42c1;"></i>
                    <div style="font-size:11px;margin-top:5px;">About Us</div>
                </div>`,
        category: 'Sections',
        content: `
            <section class="about-section py-5">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 mb-4">
                            <img src="https://via.placeholder.com/600x400/667EEA/FFFFFF?text=About+Us" class="img-fluid rounded shadow" alt="About">
                        </div>
                        <div class="col-lg-6">
                            <h2 class="mb-4">About Our Company</h2>
                            <p class="lead">We are dedicated to providing excellent service to our customers.</p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <ul class="list-unstyled">
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Professional Team</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Quality Service</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>24/7 Support</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    bm.add('services-section', {
        label: `<div style="text-align:center">
                    <i class="fas fa-cogs" style="font-size:28px;color:#20c997;"></i>
                    <div style="font-size:11px;margin-top:5px;">Services</div>
                </div>`,
        category: 'Sections',
        content: `
            <section class="services-section py-5 bg-light">
                <div class="container">
                    <h2 class="text-center mb-5">Our Services</h2>
                    <div class="row g-4">
                        <div class="col-md-4">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body text-center">
                                    <div class="icon-circle bg-primary text-white rounded-circle mx-auto mb-3" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center;">
                                        <i class="fas fa-laptop-code fa-2x"></i>
                                    </div>
                                    <h4>Web Development</h4>
                                    <p>Create stunning websites that work perfectly on all devices.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body text-center">
                                    <div class="icon-circle bg-success text-white rounded-circle mx-auto mb-3" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center;">
                                        <i class="fas fa-mobile-alt fa-2x"></i>
                                    </div>
                                    <h4>Mobile Apps</h4>
                                    <p>Build native and cross-platform mobile applications.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body text-center">
                                    <div class="icon-circle bg-info text-white rounded-circle mx-auto mb-3" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center;">
                                        <i class="fas fa-palette fa-2x"></i>
                                    </div>
                                    <h4>UI/UX Design</h4>
                                    <p>Design beautiful and intuitive user interfaces.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    bm.add('portfolio-section', {
        label: `<div style="text-align:center">
                    <i class="fas fa-folder-open" style="font-size:28px;color:#e83e8c;"></i>
                    <div style="font-size:11px;margin-top:5px;">Portfolio</div>
                </div>`,
        category: 'Sections',
        content: `
            <section class="portfolio-section py-5">
                <div class="container">
                    <h2 class="text-center mb-5">Our Portfolio</h2>
                    <div class="row g-4">
                        ${[1,2,3,4,5,6].map(i => `
                            <div class="col-md-4">
                                <div class="card border-0 shadow-sm">
                                    <img src="https://via.placeholder.com/400x300/764BA2/FFFFFF?text=Project+${i}" class="card-img-top" alt="Project ${i}">
                                    <div class="card-body">
                                        <h5>Project ${i}</h5>
                                        <p class="text-muted">Web Design & Development</p>
                                        <a href="#" class="btn btn-sm btn-outline-primary">View Details</a>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </section>
        `
    });

    bm.add('blog-section', {
        label: `<div style="text-align:center">
                    <i class="fas fa-blog" style="font-size:28px;color:#fd7e14;"></i>
                    <div style="font-size:11px;margin-top:5px;">Blog Posts</div>
                </div>`,
        category: 'Sections',
        content: `
            <section class="blog-section py-5">
                <div class="container">
                    <h2 class="text-center mb-5">Latest Blog Posts</h2>
                    <div class="row g-4">
                        ${[1,2,3].map(i => `
                            <div class="col-md-4">
                                <article class="card h-100 border-0 shadow-sm">
                                    <img src="https://via.placeholder.com/400x250/F093FB/FFFFFF?text=Blog+${i}" class="card-img-top" alt="Blog ${i}">
                                    <div class="card-body">
                                        <div class="mb-2">
                                            <span class="badge bg-primary">Technology</span>
                                            <small class="text-muted ms-2"><i class="far fa-calendar"></i> Jan ${i}, 2024</small>
                                        </div>
                                        <h5 class="card-title">Blog Post Title ${i}</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
                                        <a href="#" class="btn btn-link p-0">Read More <i class="fas fa-arrow-right"></i></a>
                                    </div>
                                </article>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </section>
        `
    });

    bm.add('faq-section', {
        label: `<div style="text-align:center">
                    <i class="fas fa-question-circle" style="font-size:28px;color:#ffc107;"></i>
                    <div style="font-size:11px;margin-top:5px;">FAQ</div>
                </div>`,
        category: 'Sections',
        content: `
            <section class="faq-section py-5 bg-light">
                <div class="container">
                    <h2 class="text-center mb-5">Frequently Asked Questions</h2>
                    <div class="row justify-content-center">
                        <div class="col-lg-8">
                            <div class="accordion" id="faqAccordion">
                                ${[1,2,3,4].map(i => `
                                    <div class="accordion-item mb-3 border-0 shadow-sm">
                                        <h3 class="accordion-header">
                                            <button class="accordion-button ${i !== 1 ? 'collapsed' : ''}" type="button" data-bs-toggle="collapse" data-bs-target="#faq${i}">
                                                Question ${i}: How does it work?
                                            </button>
                                        </h3>
                                        <div id="faq${i}" class="accordion-collapse collapse ${i === 1 ? 'show' : ''}" data-bs-parent="#faqAccordion">
                                            <div class="accordion-body">
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                            </div>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    // ========== MORE CARDS ==========
    bm.add('card-blog', {
        label: `<div style="text-align:center">
                    <i class="fas fa-newspaper" style="font-size:28px;color:#20c997;"></i>
                    <div style="font-size:11px;margin-top:5px;">Blog Card</div>
                </div>`,
        category: 'Cards',
        content: `
            <div class="card shadow-sm" style="max-width:350px;">
                <img src="https://via.placeholder.com/350x200/4FACFE/FFFFFF?text=Blog" class="card-img-top" alt="Blog">
                <div class="card-body">
                    <div class="mb-2">
                        <span class="badge bg-info">News</span>
                        <small class="text-muted ms-2"><i class="far fa-clock"></i> 5 min read</small>
                    </div>
                    <h5 class="card-title">Article Title</h5>
                    <p class="card-text">Brief description of the blog post goes here...</p>
                    <div class="d-flex align-items-center mt-3">
                        <img src="https://via.placeholder.com/40" class="rounded-circle me-2" alt="Author">
                        <div>
                            <small class="fw-bold">John Doe</small><br>
                            <small class="text-muted">Jan 15, 2024</small>
                        </div>
                    </div>
                </div>
            </div>
        `
    });

    bm.add('card-testimonial', {
        label: `<div style="text-align:center">
                    <i class="fas fa-quote-right" style="font-size:28px;color:#6f42c1;"></i>
                    <div style="font-size:11px;margin-top:5px;">Testimonial Card</div>
                </div>`,
        category: 'Cards',
        content: `
            <div class="card border-0 shadow" style="max-width:350px;">
                <div class="card-body">
                    <div class="mb-3">
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                    </div>
                    <p class="card-text">"This is an amazing product! It exceeded all my expectations and I highly recommend it to everyone."</p>
                    <div class="d-flex align-items-center mt-3">
                        <img src="https://via.placeholder.com/50" class="rounded-circle me-3" alt="User">
                        <div>
                            <h6 class="mb-0">Sarah Johnson</h6>
                            <small class="text-muted">CEO, Tech Corp</small>
                        </div>
                    </div>
                </div>
            </div>
        `
    });

    bm.add('card-product', {
        label: `<div style="text-align:center">
                    <i class="fas fa-shopping-bag" style="font-size:28px;color:#dc3545;"></i>
                    <div style="font-size:11px;margin-top:5px;">Product Card</div>
                </div>`,
        category: 'Cards',
        content: `
            <div class="card shadow-sm" style="max-width:300px;">
                <div class="position-relative">
                    <img src="https://via.placeholder.com/300x300/667EEA/FFFFFF?text=Product" class="card-img-top" alt="Product">
                    <span class="badge bg-danger position-absolute top-0 end-0 m-2">Sale</span>
                </div>
                <div class="card-body">
                    <h5 class="card-title">Product Name</h5>
                    <div class="mb-2">
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="far fa-star text-warning"></i>
                        <small class="text-muted">(24 reviews)</small>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <span class="text-muted text-decoration-line-through">$99</span>
                            <span class="h5 text-danger ms-2">$79</span>
                        </div>
                        <button class="btn btn-primary btn-sm">
                            <i class="fas fa-shopping-cart"></i> Add
                        </button>
                    </div>
                </div>
            </div>
        `
    });

    // ========== FORMS ==========
    bm.add('form-login', {
        label: `<div style="text-align:center">
                    <i class="fas fa-sign-in-alt" style="font-size:28px;color:#007bff;"></i>
                    <div style="font-size:11px;margin-top:5px;">Login Form</div>
                </div>`,
        category: 'Forms',
        content: `
            <div class="card shadow" style="max-width:400px;margin:auto;">
                <div class="card-body p-4">
                    <h3 class="text-center mb-4">Login</h3>
                    <form>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" placeholder="Enter email">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control" placeholder="Enter password">
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="remember">
                            <label class="form-check-label" for="remember">Remember me</label>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Login</button>
                        <div class="text-center mt-3">
                            <a href="#" class="text-decoration-none">Forgot password?</a>
                        </div>
                    </form>
                </div>
            </div>
        `
    });

    bm.add('form-register', {
        label: `<div style="text-align:center">
                    <i class="fas fa-user-plus" style="font-size:28px;color:#28a745;"></i>
                    <div style="font-size:11px;margin-top:5px;">Register Form</div>
                </div>`,
        category: 'Forms',
        content: `
            <div class="card shadow" style="max-width:500px;margin:auto;">
                <div class="card-body p-4">
                    <h3 class="text-center mb-4">Create Account</h3>
                    <form>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">First Name</label>
                                <input type="text" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Last Name</label>
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm Password</label>
                            <input type="password" class="form-control">
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="terms">
                            <label class="form-check-label" for="terms">I agree to the terms and conditions</label>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Register</button>
                    </form>
                </div>
            </div>
        `
    });

    bm.add('form-search', {
        label: `<div style="text-align:center">
                    <i class="fas fa-search" style="font-size:28px;color:#17a2b8;"></i>
                    <div style="font-size:11px;margin-top:5px;">Search Form</div>
                </div>`,
        category: 'Forms',
        content: `
            <form class="d-flex" style="max-width:600px;">
                <input type="search" class="form-control me-2" placeholder="Search...">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i> Search
                </button>
            </form>
        `
    });

    // ========== NAVIGATION ==========
    bm.add('pagination', {
        label: `<div style="text-align:center">
                    <i class="fas fa-list-ol" style="font-size:28px;color:#6c757d;"></i>
                    <div style="font-size:11px;margin-top:5px;">Pagination</div>
                </div>`,
        category: 'Navigation',
        content: `
            <nav>
                <ul class="pagination">
                    <li class="page-item disabled">
                        <a class="page-link" href="#"><i class="fas fa-chevron-left"></i></a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item active"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link" href="#">4</a></li>
                    <li class="page-item"><a class="page-link" href="#">5</a></li>
                    <li class="page-item">
                        <a class="page-link" href="#"><i class="fas fa-chevron-right"></i></a>
                    </li>
                </ul>
            </nav>
        `
    });

    bm.add('tabs', {
        label: `<div style="text-align:center">
                    <i class="fas fa-folder" style="font-size:28px;color:#fd7e14;"></i>
                    <div style="font-size:11px;margin-top:5px;">Tabs</div>
                </div>`,
        category: 'Navigation',
        content: `
            <div>
                <ul class="nav nav-tabs mb-3">
                    <li class="nav-item">
                        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab1">Tab 1</button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab2">Tab 2</button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab3">Tab 3</button>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="tab1">
                        <p>Content for Tab 1</p>
                    </div>
                    <div class="tab-pane fade" id="tab2">
                        <p>Content for Tab 2</p>
                    </div>
                    <div class="tab-pane fade" id="tab3">
                        <p>Content for Tab 3</p>
                    </div>
                </div>
            </div>
        `
    });

    // ========== COMPONENTS ==========
    bm.add('badge', {
        label: `<div style="text-align:center">
                    <i class="fas fa-tag" style="font-size:28px;color:#ffc107;"></i>
                    <div style="font-size:11px;margin-top:5px;">Badges</div>
                </div>`,
        category: 'Components',
        content: `
            <div>
                <span class="badge bg-primary me-1">Primary</span>
                <span class="badge bg-secondary me-1">Secondary</span>
                <span class="badge bg-success me-1">Success</span>
                <span class="badge bg-danger me-1">Danger</span>
                <span class="badge bg-warning text-dark me-1">Warning</span>
                <span class="badge bg-info me-1">Info</span>
            </div>
        `
    });

    bm.add('progress-bar', {
        label: `<div style="text-align:center">
                    <i class="fas fa-tasks" style="font-size:28px;color:#007bff;"></i>
                    <div style="font-size:11px;margin-top:5px;">Progress Bars</div>
                </div>`,
        category: 'Components',
        content: `
            <div style="max-width:600px;">
                <div class="mb-3">
                    <label class="form-label">HTML & CSS</label>
                    <div class="progress">
                        <div class="progress-bar bg-success" style="width: 90%">90%</div>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">JavaScript</label>
                    <div class="progress">
                        <div class="progress-bar bg-info" style="width: 75%">75%</div>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">PHP</label>
                    <div class="progress">
                        <div class="progress-bar bg-warning" style="width: 60%">60%</div>
                    </div>
                </div>
            </div>
        `
    });

    bm.add('modal-trigger', {
        label: `<div style="text-align:center">
                    <i class="fas fa-window-maximize" style="font-size:28px;color:#6f42c1;"></i>
                    <div style="font-size:11px;margin-top:5px;">Modal</div>
                </div>`,
        category: 'Components',
        content: `
            <div>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Launch Modal
                </button>
                <div class="modal fade" id="exampleModal" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Modal Title</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <p>Modal content goes here...</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary">Save changes</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `
    });

    bm.add('carousel', {
        label: `<div style="text-align:center">
                    <i class="fas fa-images" style="font-size:28px;color:#e83e8c;"></i>
                    <div style="font-size:11px;margin-top:5px;">Carousel</div>
                </div>`,
        category: 'Components',
        content: `
            <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="0" class="active"></button>
                    <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="1"></button>
                    <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="2"></button>
                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="https://via.placeholder.com/800x400/FF6B6B/FFFFFF?text=Slide+1" class="d-block w-100" alt="Slide 1">
                        <div class="carousel-caption">
                            <h5>First Slide</h5>
                            <p>Description for first slide</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="https://via.placeholder.com/800x400/4ECDC4/FFFFFF?text=Slide+2" class="d-block w-100" alt="Slide 2">
                        <div class="carousel-caption">
                            <h5>Second Slide</h5>
                            <p>Description for second slide</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="https://via.placeholder.com/800x400/45B7D1/FFFFFF?text=Slide+3" class="d-block w-100" alt="Slide 3">
                        <div class="carousel-caption">
                            <h5>Third Slide</h5>
                            <p>Description for third slide</p>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </button>
            </div>
        `
    });

    bm.add('list-group', {
        label: `<div style="text-align:center">
                    <i class="fas fa-list-ul" style="font-size:28px;color:#28a745;"></i>
                    <div style="font-size:11px;margin-top:5px;">List Group</div>
                </div>`,
        category: 'Components',
        content: `
            <ul class="list-group" style="max-width:400px;">
                <li class="list-group-item active">Active item</li>
                <li class="list-group-item">Second item</li>
                <li class="list-group-item">Third item</li>
                <li class="list-group-item">Fourth item</li>
                <li class="list-group-item">Fifth item</li>
            </ul>
        `
    });

    // ========== RAW HTML BLOCK ==========
    bm.add('raw-html', {
        label: `<div style="text-align:center">
                    <i class="fas fa-code" style="font-size:28px;color:#e74c3c;"></i>
                    <div style="font-size:11px;margin-top:5px;">Raw HTML</div>
                </div>`,
        category: 'Components',
        content: {
            type: 'raw-html',
            'raw-html': `<div class="custom-html-wrapper" style="padding: 20px; border: 2px dashed #e74c3c; border-radius: 8px; text-align: center; background: #f8f9fa;">
    <i class="fas fa-code" style="font-size: 48px; color: #e74c3c; margin-bottom: 10px;"></i>
    <h4 style="color: #e74c3c; margin: 10px 0;">Custom HTML Component</h4>
    <p style="color: #6c757d;">Double-click or click "Edit Code" to add your custom HTML, CSS, and JavaScript</p>
</div>`,
            'raw-css': `.custom-html-wrapper:hover {
    background: #e9ecef;
    transition: all 0.3s ease;
}`,
            'raw-js': '// Add your JavaScript code here\nconsole.log("Raw HTML component loaded");'
        }
    });

    // ========== ACCORDION COMPONENTS ==========
    bm.add('accordion-basic', {
        label: `<div style="text-align:center">
                    <i class="fas fa-bars" style="font-size:28px;color:#0d6efd;"></i>
                    <div style="font-size:11px;margin-top:5px;">Accordion</div>
                </div>`,
        category: 'Components',
        content: function() {
            const uid = 'acc' + Date.now();
            return `
            <style>
                #${uid} .accordion-button {
                    cursor: pointer;
                    border: none;
                    background: none;
                    text-align: left;
                    width: 100%;
                }
                #${uid} .accordion-button:focus {
                    outline: none;
                    box-shadow: none;
                }
            </style>
            <div class="accordion" id="${uid}">
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-1" aria-expanded="true" aria-controls="${uid}-1">
                            First Accordion Item
                        </button>
                    </h2>
                    <div id="${uid}-1" class="accordion-collapse collapse show" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            <strong>This is the first item's accordion body.</strong> It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions.
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-2" aria-expanded="false" aria-controls="${uid}-2">
                            Second Accordion Item
                        </button>
                    </h2>
                    <div id="${uid}-2" class="accordion-collapse collapse" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            <strong>This is the second item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. You can modify any of this with custom CSS or overriding our default variables.
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-3" aria-expanded="false" aria-controls="${uid}-3">
                            Third Accordion Item
                        </button>
                    </h2>
                    <div id="${uid}-3" class="accordion-collapse collapse" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. You can add more items or customize as needed.
                        </div>
                    </div>
                </div>
            </div>
        `;
        }
    });

    bm.add('accordion-with-icons', {
        label: `<div style="text-align:center">
                    <i class="fas fa-list-ul" style="font-size:28px;color:#6f42c1;"></i>
                    <div style="font-size:11px;margin-top:5px;">Accordion Icons</div>
                </div>`,
        category: 'Components',
        content: function() {
            const uid = 'acci' + Date.now();
            return `
            <style>
                #${uid} .accordion-button {
                    cursor: pointer;
                    border: none;
                    background: none;
                    text-align: left;
                    width: 100%;
                }
                #${uid} .accordion-button:focus {
                    outline: none;
                    box-shadow: none;
                }
            </style>
            <div class="accordion accordion-flush" id="${uid}">
                <div class="accordion-item border rounded mb-2 shadow-sm">
                    <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-1" aria-expanded="true" aria-controls="${uid}-1">
                            <i class="fas fa-rocket text-primary me-3" style="font-size: 20px;"></i>
                            <span class="fw-bold">Features & Capabilities</span>
                        </button>
                    </h2>
                    <div id="${uid}-1" class="accordion-collapse collapse show" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            <p class="mb-0">Explore our powerful features designed to help you achieve your goals. From advanced analytics to seamless integrations, we've got everything you need to succeed.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item border rounded mb-2 shadow-sm">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-2" aria-expanded="false" aria-controls="${uid}-2">
                            <i class="fas fa-cog text-success me-3" style="font-size: 20px;"></i>
                            <span class="fw-bold">Configuration & Settings</span>
                        </button>
                    </h2>
                    <div id="${uid}-2" class="accordion-collapse collapse" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            <p class="mb-0">Customize your experience with flexible configuration options. Adjust settings to match your workflow and preferences with just a few clicks.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item border rounded mb-2 shadow-sm">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-3" aria-expanded="false" aria-controls="${uid}-3">
                            <i class="fas fa-shield-alt text-info me-3" style="font-size: 20px;"></i>
                            <span class="fw-bold">Security & Privacy</span>
                        </button>
                    </h2>
                    <div id="${uid}-3" class="accordion-collapse collapse" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            <p class="mb-0">Your data is protected with enterprise-grade security measures. We use industry-standard encryption and follow best practices to keep your information safe.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item border rounded mb-2 shadow-sm">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-4" aria-expanded="false" aria-controls="${uid}-4">
                            <i class="fas fa-headset text-warning me-3" style="font-size: 20px;"></i>
                            <span class="fw-bold">Support & Resources</span>
                        </button>
                    </h2>
                    <div id="${uid}-4" class="accordion-collapse collapse" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            <p class="mb-0">Get help when you need it with our comprehensive support resources. Access documentation, tutorials, and contact our dedicated support team 24/7.</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        }
    });

    bm.add('accordion-numbered', {
        label: `<div style="text-align:center">
                    <i class="fas fa-sort-numeric-down" style="font-size:28px;color:#7c6eb5;"></i>
                    <div style="font-size:11px;margin-top:5px;">Numbered Accordion</div>
                </div>`,
        category: 'Components',
        content: function() {
            const uid = 'accn' + Date.now();
            return `
            <style>
                #${uid} .accordion-button {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    border: none;
                    padding: 15px 20px;
                    font-weight: 600;
                    position: relative;
                    cursor: pointer;
                    text-align: left;
                    width: 100%;
                }
                #${uid} .accordion-button:focus {
                    outline: none;
                }
                #${uid} .accordion-button:not(.collapsed) {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    box-shadow: none;
                }
                #${uid} .accordion-button::after {
                    filter: brightness(0) invert(1);
                }
                #${uid} .accordion-item {
                    border: none;
                    margin-bottom: 8px;
                    border-radius: 6px;
                    overflow: hidden;
                }
                #${uid} .accordion-body {
                    background: #f8f9fa;
                    padding: 20px;
                    color: #666;
                    line-height: 1.6;
                }
                #${uid} .section-number {
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    width: 32px;
                    height: 32px;
                    background: rgba(255,255,255,0.2);
                    border-radius: 50%;
                    margin-right: 12px;
                    font-weight: bold;
                }
            </style>
            <div class="accordion numbered-accordion" id="${uid}">
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-1" aria-expanded="true" aria-controls="${uid}-1">
                            <span class="section-number">1</span>
                            <span>Section 1</span>
                        </button>
                    </h2>
                    <div id="${uid}-1" class="accordion-collapse collapse show" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-2" aria-expanded="false" aria-controls="${uid}-2">
                            <span class="section-number">2</span>
                            <span>Section 2</span>
                        </button>
                    </h2>
                    <div id="${uid}-2" class="accordion-collapse collapse" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-3" aria-expanded="false" aria-controls="${uid}-3">
                            <span class="section-number">3</span>
                            <span>Section 3</span>
                        </button>
                    </h2>
                    <div id="${uid}-3" class="accordion-collapse collapse" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                        </div>
                    </div>
                </div>
            </div>
        `;
        }
    });

    bm.add('accordion-modern', {
        label: `<div style="text-align:center">
                    <i class="fas fa-align-justify" style="font-size:28px;color:#4a5568;"></i>
                    <div style="font-size:11px;margin-top:5px;">Modern Accordion</div>
                </div>`,
        category: 'Components',
        content: function() {
            const uid = 'accm' + Date.now();
            return `
            <style>
                #${uid} {
                    background: #f3f4f6;
                    padding: 20px;
                }
                #${uid} .accordion-item {
                    border: none;
                    margin-bottom: 12px;
                    border-radius: 8px;
                    overflow: hidden;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
                    background: white;
                }
                #${uid} .accordion-button {
                    background: #4a5568;
                    color: white;
                    border: none;
                    padding: 18px 24px;
                    font-weight: 600;
                    font-size: 16px;
                    border-radius: 8px;
                    cursor: pointer;
                    text-align: left;
                    width: 100%;
                }
                #${uid} .accordion-button:focus {
                    outline: none;
                }
                #${uid} .accordion-button:not(.collapsed) {
                    background: #4a5568;
                    color: white;
                    box-shadow: none;
                    border-bottom-left-radius: 0;
                    border-bottom-right-radius: 0;
                }
                #${uid} .accordion-button.collapsed {
                    border-radius: 8px;
                }
                #${uid} .accordion-button::after {
                    filter: brightness(0) invert(1);
                }
                #${uid} .accordion-body {
                    background: white;
                    padding: 24px;
                    color: #4b5563;
                    line-height: 1.7;
                    border-top: 1px solid #e5e7eb;
                }
            </style>
            <div class="accordion modern-accordion" id="${uid}">
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-1" aria-expanded="true" aria-controls="${uid}-1">
                            Features
                        </button>
                    </h2>
                    <div id="${uid}-1" class="accordion-collapse collapse show" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            Discover our product's cutting-edge features designed to enhance your productivity and streamline your workflow.
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-2" aria-expanded="false" aria-controls="${uid}-2">
                            Pricing
                        </button>
                    </h2>
                    <div id="${uid}-2" class="accordion-collapse collapse" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            Choose from our flexible pricing plans designed to fit businesses of all sizes. We offer competitive rates with no hidden fees.
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#${uid}-3" aria-expanded="false" aria-controls="${uid}-3">
                            Support
                        </button>
                    </h2>
                    <div id="${uid}-3" class="accordion-collapse collapse" data-bs-parent="#${uid}">
                        <div class="accordion-body">
                            Our dedicated support team is available 24/7 to assist you with any questions or issues you may encounter.
                        </div>
                    </div>
                </div>
            </div>
        `;
        }
    });

    console.log('Extended Blocks: 30+ additional components registered (including Raw HTML & Accordions)');
};
