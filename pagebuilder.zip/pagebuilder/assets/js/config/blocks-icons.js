/**
 * Icon Picker Components - Google Fonts & Font Awesome
 */

function registerIconBlocks(editor) {
    const bm = editor.BlockManager;
    const comps = editor.DomComponents;

    // Popular Font Awesome icons array
    const faIcons = [
        'fa-home', 'fa-user', 'fa-heart', 'fa-star', 'fa-envelope', 'fa-phone',
        'fa-shopping-cart', 'fa-search', 'fa-check', 'fa-times', 'fa-bars',
        'fa-cog', 'fa-bell', 'fa-camera', 'fa-map-marker-alt', 'fa-calendar',
        'fa-clock', 'fa-download', 'fa-upload', 'fa-trash', 'fa-edit', 'fa-save',
        'fa-share', 'fa-thumbs-up', 'fa-comment', 'fa-play', 'fa-pause', 'fa-stop',
        'fa-facebook', 'fa-twitter', 'fa-instagram', 'fa-linkedin', 'fa-youtube',
        'fa-github', 'fa-arrow-right', 'fa-arrow-left', 'fa-arrow-up', 'fa-arrow-down',
        'fa-plus', 'fa-minus', 'fa-info-circle', 'fa-exclamation-triangle', 'fa-question-circle',
        'fa-lightbulb', 'fa-rocket', 'fa-trophy', 'fa-gift', 'fa-key', 'fa-lock'
    ];

    // Popular Google Material icons array
    const materialIcons = [
        'home', 'person', 'favorite', 'star', 'mail', 'phone',
        'shopping_cart', 'search', 'check', 'close', 'menu',
        'settings', 'notifications', 'camera', 'location_on', 'calendar_today',
        'schedule', 'download', 'upload', 'delete', 'edit', 'save',
        'share', 'thumb_up', 'comment', 'play_arrow', 'pause', 'stop',
        'facebook', 'arrow_forward', 'arrow_back', 'arrow_upward', 'arrow_downward',
        'add', 'remove', 'info', 'warning', 'help',
        'lightbulb', 'emoji_events', 'card_giftcard', 'vpn_key', 'lock'
    ];

    // Register Custom Font Awesome Icon Component
    comps.addType('fa-icon', {
        model: {
            defaults: {
                tagName: 'i',
                attributes: { class: 'fas fa-star' },
                style: { 'font-size': '24px', 'color': '#007bff' },
                traits: [
                    {
                        type: 'select',
                        label: 'Icon',
                        name: 'class',
                        options: faIcons.map(icon => ({
                            id: `fas ${icon}`,
                            name: icon.replace('fa-', '').replace(/-/g, ' ')
                        }))
                    },
                    {
                        type: 'color',
                        label: 'Color',
                        name: 'icon-color',
                        changeProp: 1
                    },
                    {
                        type: 'number',
                        label: 'Size (px)',
                        name: 'icon-size',
                        changeProp: 1,
                        min: 12,
                        max: 200
                    }
                ]
            },
            init() {
                // Handle color changes
                this.on('change:icon-color', this.updateIconColor);
                this.on('change:icon-size', this.updateIconSize);
                
                // Initialize from style
                const style = this.getStyle();
                if (style.color) {
                    this.set('icon-color', style.color);
                }
                if (style['font-size']) {
                    this.set('icon-size', parseInt(style['font-size']));
                }
            },
            updateIconColor() {
                const color = this.get('icon-color');
                if (color) {
                    this.addStyle({ color: color });
                }
            },
            updateIconSize() {
                const size = this.get('icon-size');
                if (size) {
                    this.addStyle({ 'font-size': size + 'px' });
                }
            }
        }
    });

    // Register Custom Google Material Icon Component
    comps.addType('material-icon', {
        model: {
            defaults: {
                tagName: 'span',
                attributes: { class: 'material-icons' },
                content: 'star',
                style: { 'font-size': '24px', 'color': '#007bff' },
                traits: [
                    {
                        type: 'select',
                        label: 'Icon',
                        name: 'content',
                        changeProp: 1,
                        options: materialIcons.map(icon => ({
                            id: icon,
                            name: icon.replace(/_/g, ' ')
                        }))
                    },
                    {
                        type: 'color',
                        label: 'Color',
                        name: 'icon-color',
                        changeProp: 1
                    },
                    {
                        type: 'number',
                        label: 'Size (px)',
                        name: 'icon-size',
                        changeProp: 1,
                        min: 12,
                        max: 200
                    }
                ]
            },
            init() {
                // Handle color changes
                this.on('change:icon-color', this.updateIconColor);
                this.on('change:icon-size', this.updateIconSize);
                this.on('change:content', this.updateContent);
                
                // Initialize from style
                const style = this.getStyle();
                if (style.color) {
                    this.set('icon-color', style.color);
                }
                if (style['font-size']) {
                    this.set('icon-size', parseInt(style['font-size']));
                }
            },
            updateIconColor() {
                const color = this.get('icon-color');
                if (color) {
                    this.addStyle({ color: color });
                }
            },
            updateIconSize() {
                const size = this.get('icon-size');
                if (size) {
                    this.addStyle({ 'font-size': size + 'px' });
                }
            },
            updateContent() {
                const view = this.view;
                if (view && view.el) {
                    view.el.textContent = this.get('content');
                }
            }
        },
        view: {
            onRender() {
                const content = this.model.get('content');
                this.el.textContent = content;
            }
        }
    });

    // Font Awesome Icon Block
    bm.add('fa-icon-single', {
        label: `<div style="text-align:center">
                    <i class="fas fa-icons" style="font-size:32px;color:#007bff;"></i>
                    <div style="font-size:11px;margin-top:5px;">Font Awesome Icon</div>
                </div>`,
        category: 'Icons',
        content: { type: 'fa-icon' }
    });

    // Material Icon Block
    bm.add('material-icon-single', {
        label: `<div style="text-align:center">
                    <span class="material-icons" style="font-size:32px;color:#4285f4;">grade</span>
                    <div style="font-size:11px;margin-top:5px;">Google Icon</div>
                </div>`,
        category: 'Icons',
        content: { type: 'material-icon' }
    });

    // Icon Grid - Font Awesome
    bm.add('fa-icon-grid', {
        label: `<div style="text-align:center">
                    <div style="display:flex;gap:5px;justify-content:center;font-size:20px;color:#007bff;">
                        <i class="fas fa-home"></i>
                        <i class="fas fa-user"></i>
                        <i class="fas fa-heart"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <div style="font-size:11px;margin-top:5px;">FA Icon Grid</div>
                </div>`,
        category: 'Icons',
        content: `
            <div class="container my-4">
                <div class="row text-center">
                    <div class="col-md-3 mb-3">
                        <i class="fas fa-home fa-3x text-primary mb-2"></i>
                        <p>Home</p>
                    </div>
                    <div class="col-md-3 mb-3">
                        <i class="fas fa-user fa-3x text-success mb-2"></i>
                        <p>User</p>
                    </div>
                    <div class="col-md-3 mb-3">
                        <i class="fas fa-heart fa-3x text-danger mb-2"></i>
                        <p>Favorite</p>
                    </div>
                    <div class="col-md-3 mb-3">
                        <i class="fas fa-star fa-3x text-warning mb-2"></i>
                        <p>Rating</p>
                    </div>
                </div>
            </div>
        `
    });

    // Icon Grid - Material
    bm.add('material-icon-grid', {
        label: `<div style="text-align:center">
                    <div style="display:flex;gap:5px;justify-content:center;font-size:20px;color:#4285f4;">
                        <span class="material-icons">home</span>
                        <span class="material-icons">person</span>
                        <span class="material-icons">favorite</span>
                        <span class="material-icons">star</span>
                    </div>
                    <div style="font-size:11px;margin-top:5px;">Google Icon Grid</div>
                </div>`,
        category: 'Icons',
        content: `
            <div class="container my-4">
                <div class="row text-center">
                    <div class="col-md-3 mb-3">
                        <span class="material-icons" style="font-size:48px;color:#007bff;">home</span>
                        <p>Home</p>
                    </div>
                    <div class="col-md-3 mb-3">
                        <span class="material-icons" style="font-size:48px;color:#28a745;">person</span>
                        <p>User</p>
                    </div>
                    <div class="col-md-3 mb-3">
                        <span class="material-icons" style="font-size:48px;color:#dc3545;">favorite</span>
                        <p>Favorite</p>
                    </div>
                    <div class="col-md-3 mb-3">
                        <span class="material-icons" style="font-size:48px;color:#ffc107;">star</span>
                        <p>Rating</p>
                    </div>
                </div>
            </div>
        `
    });

    // Icon Feature Box - Font Awesome
    bm.add('fa-feature-box', {
        label: `<div style="text-align:center">
                    <i class="fas fa-rocket" style="font-size:28px;color:#007bff;"></i>
                    <div style="font-size:11px;margin-top:5px;">FA Feature Box</div>
                </div>`,
        category: 'Icons',
        content: `
            <div class="container my-5">
                <div class="row">
                    <div class="col-md-4 text-center mb-4">
                        <div class="mb-3">
                            <i class="fas fa-rocket fa-4x text-primary"></i>
                        </div>
                        <h4>Fast Performance</h4>
                        <p>Lightning fast loading speeds for optimal user experience.</p>
                    </div>
                    <div class="col-md-4 text-center mb-4">
                        <div class="mb-3">
                            <i class="fas fa-shield-alt fa-4x text-success"></i>
                        </div>
                        <h4>Secure & Safe</h4>
                        <p>Bank-level security to protect your data and privacy.</p>
                    </div>
                    <div class="col-md-4 text-center mb-4">
                        <div class="mb-3">
                            <i class="fas fa-mobile-alt fa-4x text-info"></i>
                        </div>
                        <h4>Mobile Ready</h4>
                        <p>Fully responsive design that works on all devices.</p>
                    </div>
                </div>
            </div>
        `
    });

    // Icon Feature Box - Material
    bm.add('material-feature-box', {
        label: `<div style="text-align:center">
                    <span class="material-icons" style="font-size:28px;color:#4285f4;">rocket_launch</span>
                    <div style="font-size:11px;margin-top:5px;">Google Feature Box</div>
                </div>`,
        category: 'Icons',
        content: `
            <div class="container my-5">
                <div class="row">
                    <div class="col-md-4 text-center mb-4">
                        <div class="mb-3">
                            <span class="material-icons" style="font-size:64px;color:#007bff;">speed</span>
                        </div>
                        <h4>Fast Performance</h4>
                        <p>Lightning fast loading speeds for optimal user experience.</p>
                    </div>
                    <div class="col-md-4 text-center mb-4">
                        <div class="mb-3">
                            <span class="material-icons" style="font-size:64px;color:#28a745;">security</span>
                        </div>
                        <h4>Secure & Safe</h4>
                        <p>Bank-level security to protect your data and privacy.</p>
                    </div>
                    <div class="col-md-4 text-center mb-4">
                        <div class="mb-3">
                            <span class="material-icons" style="font-size:64px;color:#17a2b8;">devices</span>
                        </div>
                        <h4>Mobile Ready</h4>
                        <p>Fully responsive design that works on all devices.</p>
                    </div>
                </div>
            </div>
        `
    });

    // Social Icons - Font Awesome
    bm.add('fa-social-icons', {
        label: `<div style="text-align:center">
                    <div style="display:flex;gap:5px;justify-content:center;font-size:18px;">
                        <i class="fab fa-facebook" style="color:#1877f2;"></i>
                        <i class="fab fa-twitter" style="color:#1da1f2;"></i>
                        <i class="fab fa-instagram" style="color:#e4405f;"></i>
                    </div>
                    <div style="font-size:11px;margin-top:5px;">Social Icons</div>
                </div>`,
        category: 'Icons',
        content: `
            <div class="text-center my-4">
                <a href="#" class="btn btn-link text-primary mx-2">
                    <i class="fab fa-facebook fa-2x"></i>
                </a>
                <a href="#" class="btn btn-link text-info mx-2">
                    <i class="fab fa-twitter fa-2x"></i>
                </a>
                <a href="#" class="btn btn-link text-danger mx-2">
                    <i class="fab fa-instagram fa-2x"></i>
                </a>
                <a href="#" class="btn btn-link text-primary mx-2">
                    <i class="fab fa-linkedin fa-2x"></i>
                </a>
                <a href="#" class="btn btn-link text-danger mx-2">
                    <i class="fab fa-youtube fa-2x"></i>
                </a>
            </div>
        `
    });

    // Icon List - Font Awesome
    bm.add('fa-icon-list', {
        label: `<div style="text-align:center">
                    <div style="text-align:left;font-size:12px;">
                        <div><i class="fas fa-check" style="color:#28a745;"></i> Item 1</div>
                        <div><i class="fas fa-check" style="color:#28a745;"></i> Item 2</div>
                    </div>
                    <div style="font-size:11px;margin-top:5px;">Icon List</div>
                </div>`,
        category: 'Icons',
        content: `
            <div class="container my-4">
                <ul class="list-unstyled">
                    <li class="mb-2">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        Premium quality products
                    </li>
                    <li class="mb-2">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        24/7 customer support
                    </li>
                    <li class="mb-2">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        Free shipping worldwide
                    </li>
                    <li class="mb-2">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        30-day money-back guarantee
                    </li>
                    <li class="mb-2">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        Secure payment processing
                    </li>
                </ul>
            </div>
        `
    });

    // Icon with Text
    bm.add('icon-text-combo', {
        label: `<div style="text-align:center">
                    <div style="display:flex;align-items:center;justify-content:center;gap:5px;font-size:12px;">
                        <i class="fas fa-envelope"></i> Contact
                    </div>
                    <div style="font-size:11px;margin-top:5px;">Icon + Text</div>
                </div>`,
        category: 'Icons',
        content: `
            <div class="d-flex align-items-center justify-content-center my-3">
                <i class="fas fa-envelope fa-2x text-primary me-3"></i>
                <div>
                    <h5 class="mb-1">Email Us</h5>
                    <p class="mb-0 text-muted">contact@example.com</p>
                </div>
            </div>
        `
    });

    // Icon Badge
    bm.add('icon-badge', {
        label: `<div style="text-align:center">
                    <div style="display:inline-block;background:#007bff;color:white;border-radius:50%;width:32px;height:32px;line-height:32px;">
                        <i class="fas fa-star" style="font-size:14px;"></i>
                    </div>
                    <div style="font-size:11px;margin-top:5px;">Icon Badge</div>
                </div>`,
        category: 'Icons',
        content: `
            <div class="text-center my-4">
                <div class="d-inline-flex align-items-center justify-content-center bg-primary text-white rounded-circle"
                     style="width: 80px; height: 80px;">
                    <i class="fas fa-award fa-3x"></i>
                </div>
            </div>
        `
    });

    console.log('✅ Icon blocks registered');
}

// Make function globally available
window.registerIconBlocks = registerIconBlocks;
