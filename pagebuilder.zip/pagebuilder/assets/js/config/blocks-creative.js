/**
 * Creative Blocks Library
 *
 * This file registers creative blocks including galleries, testimonials,
 * pricing tables, and other advanced components.
 */

const registerCreativeBlocks = (editor) => {
    const bm = editor.BlockManager;

    // ========== GALLERY ==========
    bm.add('gallery-grid', {
        label: `<div style="text-align:center">
                    <i class="fas fa-images" style="font-size:28px;color:#e91e63;"></i>
                    <div style="font-size:11px;margin-top:5px;">Image Gallery</div>
                </div>`,
        category: 'Creative',
        content: `
            <section class="gallery-section py-5">
                <div class="container">
                    <h2 class="text-center mb-5">Our Gallery</h2>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <img src="https://via.placeholder.com/400x300/FF6B6B/FFFFFF?text=Gallery+1" class="img-fluid rounded shadow-sm" alt="Gallery 1">
                        </div>
                        <div class="col-md-4">
                            <img src="https://via.placeholder.com/400x300/4ECDC4/FFFFFF?text=Gallery+2" class="img-fluid rounded shadow-sm" alt="Gallery 2">
                        </div>
                        <div class="col-md-4">
                            <img src="https://via.placeholder.com/400x300/45B7D1/FFFFFF?text=Gallery+3" class="img-fluid rounded shadow-sm" alt="Gallery 3">
                        </div>
                        <div class="col-md-4">
                            <img src="https://via.placeholder.com/400x300/FFA07A/FFFFFF?text=Gallery+4" class="img-fluid rounded shadow-sm" alt="Gallery 4">
                        </div>
                        <div class="col-md-4">
                            <img src="https://via.placeholder.com/400x300/98D8C8/FFFFFF?text=Gallery+5" class="img-fluid rounded shadow-sm" alt="Gallery 5">
                        </div>
                        <div class="col-md-4">
                            <img src="https://via.placeholder.com/400x300/F7DC6F/FFFFFF?text=Gallery+6" class="img-fluid rounded shadow-sm" alt="Gallery 6">
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    // ========== TESTIMONIALS ==========
    bm.add('testimonials', {
        label: `<div style="text-align:center">
                    <i class="fas fa-quote-left" style="font-size:28px;color:#9c27b0;"></i>
                    <div style="font-size:11px;margin-top:5px;">Testimonials</div>
                </div>`,
        category: 'Creative',
        content: `
            <section class="testimonials-section py-5 bg-light">
                <div class="container">
                    <h2 class="text-center mb-5">What Our Clients Say</h2>
                    <div class="row">
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 shadow-sm">
                                <div class="card-body text-center">
                                    <img src="https://via.placeholder.com/100" class="rounded-circle mb-3" alt="Client">
                                    <div class="mb-3">
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                    </div>
                                    <p class="card-text">"Excellent service and outstanding support! Highly recommended for anyone looking for quality."</p>
                                    <h6 class="card-title mb-0">John Doe</h6>
                                    <small class="text-muted">CEO, Company Inc.</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 shadow-sm">
                                <div class="card-body text-center">
                                    <img src="https://via.placeholder.com/100" class="rounded-circle mb-3" alt="Client">
                                    <div class="mb-3">
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                    </div>
                                    <p class="card-text">"Best decision we made for our business. The results speak for themselves!"</p>
                                    <h6 class="card-title mb-0">Jane Smith</h6>
                                    <small class="text-muted">Manager, Business Co.</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 shadow-sm">
                                <div class="card-body text-center">
                                    <img src="https://via.placeholder.com/100" class="rounded-circle mb-3" alt="Client">
                                    <div class="mb-3">
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                    </div>
                                    <p class="card-text">"Professional, reliable, and results-driven. Couldn't ask for more!"</p>
                                    <h6 class="card-title mb-0">Mike Johnson</h6>
                                    <small class="text-muted">Director, Startup Ltd.</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    // ========== PRICING TABLE ==========
    bm.add('pricing-table', {
        label: `<div style="text-align:center">
                    <i class="fas fa-tags" style="font-size:28px;color:#ff9800;"></i>
                    <div style="font-size:11px;margin-top:5px;">Pricing Table</div>
                </div>`,
        category: 'Creative',
        content: `
            <section class="pricing-section py-5">
                <div class="container">
                    <h2 class="text-center mb-5">Choose Your Plan</h2>
                    <div class="row g-4">
                        <div class="col-md-4">
                            <div class="card text-center shadow-sm h-100">
                                <div class="card-header bg-light py-3">
                                    <h4 class="mb-0">Starter</h4>
                                </div>
                                <div class="card-body d-flex flex-column">
                                    <h2 class="mb-4">
                                        <span class="display-4 fw-bold">$9</span>
                                        <span class="text-muted fs-6">/month</span>
                                    </h2>
                                    <ul class="list-unstyled mb-4 flex-grow-1">
                                        <li class="mb-3"><i class="fas fa-check text-success me-2"></i>5 Projects</li>
                                        <li class="mb-3"><i class="fas fa-check text-success me-2"></i>2GB Storage</li>
                                        <li class="mb-3"><i class="fas fa-check text-success me-2"></i>Email Support</li>
                                        <li class="mb-3 text-muted"><i class="fas fa-times me-2"></i>Priority Support</li>
                                    </ul>
                                    <button class="btn btn-outline-primary">Get Started</button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-center shadow h-100 border-primary">
                                <div class="card-header bg-primary text-white py-3">
                                    <h4 class="mb-0">Professional</h4>
                                    <span class="badge bg-warning text-dark">Popular</span>
                                </div>
                                <div class="card-body d-flex flex-column">
                                    <h2 class="mb-4">
                                        <span class="display-4 fw-bold">$29</span>
                                        <span class="text-muted fs-6">/month</span>
                                    </h2>
                                    <ul class="list-unstyled mb-4 flex-grow-1">
                                        <li class="mb-3"><i class="fas fa-check text-success me-2"></i>50 Projects</li>
                                        <li class="mb-3"><i class="fas fa-check text-success me-2"></i>20GB Storage</li>
                                        <li class="mb-3"><i class="fas fa-check text-success me-2"></i>Priority Support</li>
                                        <li class="mb-3"><i class="fas fa-check text-success me-2"></i>Advanced Features</li>
                                    </ul>
                                    <button class="btn btn-primary">Get Started</button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-center shadow-sm h-100">
                                <div class="card-header bg-light py-3">
                                    <h4 class="mb-0">Enterprise</h4>
                                </div>
                                <div class="card-body d-flex flex-column">
                                    <h2 class="mb-4">
                                        <span class="display-4 fw-bold">$99</span>
                                        <span class="text-muted fs-6">/month</span>
                                    </h2>
                                    <ul class="list-unstyled mb-4 flex-grow-1">
                                        <li class="mb-3"><i class="fas fa-check text-success me-2"></i>Unlimited Projects</li>
                                        <li class="mb-3"><i class="fas fa-check text-success me-2"></i>100GB Storage</li>
                                        <li class="mb-3"><i class="fas fa-check text-success me-2"></i>24/7 Support</li>
                                        <li class="mb-3"><i class="fas fa-check text-success me-2"></i>Custom Integration</li>
                                    </ul>
                                    <button class="btn btn-outline-primary">Contact Sales</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    // ========== TEAM SECTION ==========
    bm.add('team-section', {
        label: `<div style="text-align:center">
                    <i class="fas fa-users" style="font-size:28px;color:#2196f3;"></i>
                    <div style="font-size:11px;margin-top:5px;">Team Members</div>
                </div>`,
        category: 'Creative',
        content: `
            <section class="team-section py-5">
                <div class="container">
                    <h2 class="text-center mb-5">Meet Our Team</h2>
                    <div class="row">
                        <div class="col-md-3 mb-4">
                            <div class="card border-0 text-center">
                                <img src="https://via.placeholder.com/200" class="card-img-top rounded-circle mx-auto mt-3" style="width: 150px; height: 150px;" alt="Team Member">
                                <div class="card-body">
                                    <h5 class="card-title">Alice Johnson</h5>
                                    <p class="text-muted">CEO & Founder</p>
                                    <div class="social-links">
                                        <a href="#" class="text-primary me-2"><i class="fab fa-linkedin"></i></a>
                                        <a href="#" class="text-info me-2"><i class="fab fa-twitter"></i></a>
                                        <a href="#" class="text-danger"><i class="fab fa-instagram"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="card border-0 text-center">
                                <img src="https://via.placeholder.com/200" class="card-img-top rounded-circle mx-auto mt-3" style="width: 150px; height: 150px;" alt="Team Member">
                                <div class="card-body">
                                    <h5 class="card-title">Bob Smith</h5>
                                    <p class="text-muted">CTO</p>
                                    <div class="social-links">
                                        <a href="#" class="text-primary me-2"><i class="fab fa-linkedin"></i></a>
                                        <a href="#" class="text-info me-2"><i class="fab fa-twitter"></i></a>
                                        <a href="#" class="text-danger"><i class="fab fa-instagram"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="card border-0 text-center">
                                <img src="https://via.placeholder.com/200" class="card-img-top rounded-circle mx-auto mt-3" style="width: 150px; height: 150px;" alt="Team Member">
                                <div class="card-body">
                                    <h5 class="card-title">Carol White</h5>
                                    <p class="text-muted">Designer</p>
                                    <div class="social-links">
                                        <a href="#" class="text-primary me-2"><i class="fab fa-linkedin"></i></a>
                                        <a href="#" class="text-info me-2"><i class="fab fa-twitter"></i></a>
                                        <a href="#" class="text-danger"><i class="fab fa-instagram"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="card border-0 text-center">
                                <img src="https://via.placeholder.com/200" class="card-img-top rounded-circle mx-auto mt-3" style="width: 150px; height: 150px;" alt="Team Member">
                                <div class="card-body">
                                    <h5 class="card-title">David Brown</h5>
                                    <p class="text-muted">Developer</p>
                                    <div class="social-links">
                                        <a href="#" class="text-primary me-2"><i class="fab fa-linkedin"></i></a>
                                        <a href="#" class="text-info me-2"><i class="fab fa-twitter"></i></a>
                                        <a href="#" class="text-danger"><i class="fab fa-instagram"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    // ========== STATS COUNTER ==========
    bm.add('stats-counter', {
        label: `<div style="text-align:center">
                    <i class="fas fa-chart-bar" style="font-size:28px;color:#4caf50;"></i>
                    <div style="font-size:11px;margin-top:5px;">Statistics Counter</div>
                </div>`,
        category: 'Creative',
        content: `
            <section class="stats-section py-5 bg-primary text-white">
                <div class="container">
                    <div class="row text-center">
                        <div class="col-md-3 mb-4">
                            <i class="fas fa-users fa-3x mb-3"></i>
                            <h2 class="display-4 fw-bold">2500+</h2>
                            <p class="lead">Happy Clients</p>
                        </div>
                        <div class="col-md-3 mb-4">
                            <i class="fas fa-project-diagram fa-3x mb-3"></i>
                            <h2 class="display-4 fw-bold">1200+</h2>
                            <p class="lead">Projects Completed</p>
                        </div>
                        <div class="col-md-3 mb-4">
                            <i class="fas fa-award fa-3x mb-3"></i>
                            <h2 class="display-4 fw-bold">50+</h2>
                            <p class="lead">Awards Won</p>
                        </div>
                        <div class="col-md-3 mb-4">
                            <i class="fas fa-clock fa-3x mb-3"></i>
                            <h2 class="display-4 fw-bold">24/7</h2>
                            <p class="lead">Support Available</p>
                        </div>
                    </div>
                </div>
            </section>
        `
    });

    console.log('Creative Blocks: Registered');
};
