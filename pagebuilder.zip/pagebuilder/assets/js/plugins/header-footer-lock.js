/**
 * Header-Footer Lock Plugin for GrapesJS
 *
 * This plugin creates non-editable header and footer sections that are locked
 * from user modification. The content is defined in the main PHP file and
 * passed through global variables.
 */

const headerFooterLockPlugin = (editor) => {
    // Register custom component types for locked sections
    editor.DomComponents.addType('header-locked', {
        model: {
            defaults: {
                name: 'Header (Locked)',
                draggable: false,
                droppable: false,
                removable: false,
                copyable: false,
                selectable: false,
                hoverable: false,
                highlightable: false,
                editable: false,
                layerable: true,
                attributes: { 'data-locked': 'true', id: 'page-header' },
                traits: []
            }
        }
    });

    editor.DomComponents.addType('footer-locked', {
        model: {
            defaults: {
                name: 'Footer (Locked)',
                draggable: false,
                droppable: false,
                removable: false,
                copyable: false,
                selectable: false,
                hoverable: false,
                highlightable: false,
                editable: false,
                layerable: true,
                attributes: { 'data-locked': 'true', id: 'page-footer' },
                traits: []
            }
        }
    });

    editor.DomComponents.addType('body-container', {
        model: {
            defaults: {
                name: 'Body Container',
                tagName: 'main',
                draggable: false,
                removable: false,
                copyable: false,
                droppable: true,
                attributes: { id: 'page-body', class: 'editable-area' },
                style: {
                    'min-height': '500px',
                    'padding': '20px'
                }
            }
        }
    });

    // Initialize locked sections on editor load
    editor.on('load', () => {
        const wrapper = editor.getWrapper();

        // Clear any existing content
        wrapper.components().reset();

        // Add header (locked) at position 0
        const header = wrapper.append({
            type: 'header-locked',
            components: HEADER_CONTENT
        }, { at: 0 })[0];

        // Add body container (editable) at position 1
        const body = wrapper.append({
            type: 'body-container',
            components: `
                <div class="container py-5">
                    <div class="row">
                        <div class="col-12">
                            <h2>Welcome to the Page Builder</h2>
                            <p>Drag and drop components from the block library to start building your page.</p>
                        </div>
                    </div>
                </div>
            `
        }, { at: 1 })[0];

        // Add footer (locked) at position 2
        const footer = wrapper.append({
            type: 'footer-locked',
            components: FOOTER_CONTENT
        }, { at: 2 })[0];

        // Force layer manager to update
        setTimeout(() => {
            editor.trigger('change:canvasOffset');
            const layerManager = editor.LayerManager;
            if (layerManager && layerManager.render) {
                layerManager.render();
            }
        }, 100);

        console.log('Header-Footer Lock Plugin: Initialized');
        console.log('Components added:', { header, body, footer });
    });

    // Prevent selection of locked components
    editor.on('component:selected', (component) => {
        const locked = component.get('attributes')?.['data-locked'];
        if (locked === 'true') {
            // Deselect locked component
            editor.select(null);
            console.log('Header-Footer Lock Plugin: Attempted to select locked component');
        }
    });

    // Prevent dropping into locked components
    editor.on('component:drag:start', (component) => {
        const wrapper = editor.getWrapper();
        const components = wrapper.components();

        components.forEach((comp) => {
            const locked = comp.get('attributes')?.['data-locked'];
            if (locked === 'true') {
                comp.set('droppable', false);
            }
        });
    });

    // Add visual indicators in layer manager
    editor.on('layer:root', () => {
        setTimeout(() => {
            const layers = document.querySelectorAll('.gjs-layer');
            layers.forEach((layer) => {
                const layerData = layer.getAttribute('data-gjs-id');
                if (layerData) {
                    const component = editor.DomComponents.getComponents().find(
                        c => c.ccid === layerData
                    );
                    if (component) {
                        const locked = component.get('attributes')?.['data-locked'];
                        if (locked === 'true') {
                            layer.setAttribute('data-locked', 'true');
                            layer.style.opacity = '0.7';
                        }
                    }
                }
            });
        }, 100);
    });

    console.log('Header-Footer Lock Plugin: Loaded');
};
