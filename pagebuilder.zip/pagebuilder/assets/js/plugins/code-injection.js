/**
 * Code Injection Plugin for GrapesJS
 *
 * This plugin allows users to edit raw HTML, CSS, and JavaScript code
 * for selected components.
 */

const codeInjectionPlugin = (editor) => {
    // Add command to open code editor
    editor.Commands.add('open-code-editor', {
        run(editor) {
            const selected = editor.getSelected();

            if (!selected) {
                alert('Please select a component first');
                return;
            }

            const modal = editor.Modal;
            modal.setTitle('Code Editor - ' + selected.get('name'));

            // Get current component code
            const currentHtml = selected.toHTML();
            const currentCss = getCssForComponent(selected, editor);
            const currentJs = selected.get('script') || selected.get('script-props')?.script || '';

            const modalContent = `
                <div class="code-editor-container">
                    <div class="code-tabs">
                        <button class="code-tab active" data-lang="html">
                            <i class="fab fa-html5"></i> HTML
                        </button>
                        <button class="code-tab" data-lang="css">
                            <i class="fab fa-css3-alt"></i> CSS
                        </button>
                        <button class="code-tab" data-lang="js">
                            <i class="fab fa-js"></i> JavaScript
                        </button>
                    </div>

                    <div class="code-editors">
                        <div class="code-editor active" id="html-editor">
                            <textarea id="html-code" rows="20">${escapeHtml(currentHtml)}</textarea>
                        </div>
                        <div class="code-editor" id="css-editor">
                            <textarea id="css-code" rows="20">${escapeHtml(currentCss)}</textarea>
                        </div>
                        <div class="code-editor" id="js-editor">
                            <textarea id="js-code" rows="20">${escapeHtml(currentJs)}</textarea>
                            <p class="text-muted small mt-2">
                                <i class="fas fa-info-circle"></i>
                                JavaScript will be executed when the component is rendered on the page.
                            </p>
                        </div>
                    </div>

                    <div class="code-editor-actions">
                        <button class="btn btn-secondary" id="cancel-code">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                        <button class="btn btn-primary" id="apply-code">
                            <i class="fas fa-check"></i> Apply Changes
                        </button>
                    </div>
                </div>
            `;

            modal.setContent(modalContent);
            modal.open();

            // Setup tab switching
            setupTabSwitching();

            // Setup action buttons
            setupCodeActions(editor, selected, modal);
        }
    });

    // Add code editor button to toolbar
    editor.on('component:selected', (component) => {
        const toolbar = component.get('toolbar');
        const codeButton = toolbar.find(item => item.command === 'open-code-editor');

        if (!codeButton) {
            toolbar.unshift({
                attributes: { class: 'fa fa-code', title: 'Edit Code' },
                command: 'open-code-editor'
            });
            component.set('toolbar', toolbar);
        }
    });

    // Helper functions
    function setupTabSwitching() {
        document.querySelectorAll('.code-tab').forEach(tab => {
            tab.addEventListener('click', function() {
                const lang = this.dataset.lang;

                document.querySelectorAll('.code-tab').forEach(t =>
                    t.classList.remove('active'));
                document.querySelectorAll('.code-editor').forEach(e =>
                    e.classList.remove('active'));

                this.classList.add('active');
                document.getElementById(lang + '-editor').classList.add('active');
            });
        });
    }

    function setupCodeActions(editor, selected, modal) {
        // Apply changes
        document.getElementById('apply-code').addEventListener('click', () => {
            const htmlCode = document.getElementById('html-code').value;
            const cssCode = document.getElementById('css-code').value;
            const jsCode = document.getElementById('js-code').value;

            try {
                // Update component HTML
                if (htmlCode.trim()) {
                    selected.components(htmlCode);
                }

                // Update CSS
                if (cssCode.trim()) {
                    const componentId = selected.getId();
                    const rule = editor.Css.getRule(`#${componentId}`);

                    const cssObj = parseCssString(cssCode);

                    if (rule) {
                        rule.setStyle(cssObj);
                    } else {
                        editor.Css.setRule(`#${componentId}`, cssObj);
                    }
                }

                // Update JavaScript
                if (jsCode.trim()) {
                    selected.set('script', jsCode);
                }

                modal.close();
                alert('Code updated successfully!');
                editor.render();
            } catch (error) {
                console.error('Error applying code:', error);
                alert('Error applying code: ' + error.message);
            }
        });

        // Cancel
        document.getElementById('cancel-code').addEventListener('click', () => {
            modal.close();
        });
    }

    function getCssForComponent(component, editor) {
        const componentId = component.getId();
        const cssRule = editor.Css.getRule(`#${componentId}`);

        if (cssRule) {
            const style = cssRule.getStyle();
            return Object.keys(style).map(prop => {
                return `  ${prop}: ${style[prop]};`;
            }).join('\n');
        }

        return '';
    }

    function parseCssString(cssString) {
        const style = {};
        const declarations = cssString.split(';');

        declarations.forEach(decl => {
            const parts = decl.split(':');
            if (parts.length >= 2) {
                const property = parts[0].trim();
                const value = parts.slice(1).join(':').trim();
                if (property && value) {
                    style[property] = value;
                }
            }
        });

        return style;
    }

    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    console.log('Code Injection Plugin: Loaded');
};
