/**
 * Page Builder - Fixed Main Initialization
 */

(function() {
    'use strict';

    console.log('🚀 Initializing Page Builder...');

    // ========== COOKIE UTILITY FUNCTIONS ==========
    const CookieManager = {
        set: function(name, value, days = 365) {
            const date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            const expires = "expires=" + date.toUTCString();
            document.cookie = name + "=" + value + ";" + expires + ";path=/";
        },
        get: function(name) {
            const nameEQ = name + "=";
            const ca = document.cookie.split(';');
            for (let i = 0; i < ca.length; i++) {
                let c = ca[i];
                while (c.charAt(0) === ' ') c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
            }
            return null;
        },
        delete: function(name) {
            document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        }
    };

    // Auto-save state (global to this module)
    // Load from cookie, default to FALSE (off)
    let autoSaveEnabled = CookieManager.get('pagebuilder_autosave') === 'true' ? true : false;
    let autoSaveInterval = null;

    console.log('📝 Auto-save preference loaded from cookie:', autoSaveEnabled);

    // Initialize editor
    const editor = grapesjs.init({
        container: '#gjs',
        height: '100%',
        width: 'auto',

        fromElement: false,

        storageManager: {
            type: 'local',
            autosave: false,
            autoload: false
        },

        blockManager: {
            appendTo: '#blocks'
        },

        assetManager: {
            upload: false,
            autoAdd: false,
            uploadText: 'Use Media Library instead',
            modalTitle: 'Please use Media Library',
            custom: {
                open() {
                    // Redirect to our custom media library
                    const selected = editor.getSelected();
                    if (selected) {
                        editor.runCommand('open-media-library', { target: selected });
                    }
                },
                close() {
                    // Do nothing
                }
            }
        },

        layerManager: {
            appendTo: '#layers-panel'
        },

        styleManager: {
            appendTo: '#styles-panel',
            sectors: [
                {
                    name: 'General',
                    open: true,
                    buildProps: ['float', 'display', 'position', 'top', 'right', 'left', 'bottom']
                },
                {
                    name: 'Dimension',
                    open: false,
                    buildProps: ['width', 'height', 'max-width', 'min-height', 'margin', 'padding']
                },
                {
                    name: 'Typography',
                    open: false,
                    buildProps: ['font-family', 'font-size', 'font-weight', 'letter-spacing', 'color', 'line-height', 'text-align']
                },
                {
                    name: 'Decorations',
                    open: false,
                    buildProps: ['background-color', 'border-radius', 'border', 'box-shadow', 'background-repeat', 'background-position', 'background-attachment', 'background-size']
                }
            ]
        },

        traitManager: {
            appendTo: '#settings-panel'
        },

        selectorManager: {
            appendTo: '#settings-panel'
        },

        panels: { defaults: [] },

        deviceManager: {
            devices: [
                { name: 'Desktop', width: '' },
                { name: 'Tablet', width: '768px' },
                { name: 'Mobile', width: '375px' }
            ]
        },

        canvas: {
            styles: [
                BOOTSTRAP_VERSION === '5'
                    ? 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'
                    : 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css',
                'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
                'https://fonts.googleapis.com/icon?family=Material+Icons'
            ],
            scripts: [
                BOOTSTRAP_VERSION === '5'
                    ? 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'
                    : 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js'
            ]
        },

        plugins: ['gjs-blocks-basic'],
        pluginsOpts: {
            'gjs-blocks-basic': {
                flexGrid: true,
                blocks: ['column1', 'column2', 'column3', 'text', 'link', 'image', 'video']
            }
        }
    });

    // Load plugins
    headerFooterLockPlugin(editor);
    codeInjectionPlugin(editor);
    registerCustomComponents(editor);
    setupMediaManager(editor);
    registerBootstrapBlocks(editor);
    registerCreativeBlocks(editor);
    if (typeof registerExtendedBlocks !== 'undefined') {
        registerExtendedBlocks(editor);
    }
    if (typeof registerTemplatesAndMore !== 'undefined') {
        registerTemplatesAndMore(editor);
    }
    if (typeof registerIconBlocks !== 'undefined') {
        registerIconBlocks(editor);
    }

    // Setup panel tabs
    setupPanelTabs();

    // Setup toolbar buttons
    setupToolbarButtons(editor);

    // Setup save/load
    setupSaveLoad(editor);

    // Auto-load on init
    editor.on('load', () => {
        console.log('✅ Editor loaded successfully');
        
        // Add custom background image button to style manager
        setupBackgroundImageButton(editor);
        
        // Initialize color pickers
        initColorPickers(editor);
        
        setTimeout(() => {
            loadPage(editor);
        }, 500);
    });

    // Store globally for debugging
    window.editor = editor;

    // Setup component search
    setupBlockSearch(editor);

    console.log('✅ Page Builder initialized successfully!');

    // Setup background image button in style manager
    function setupBackgroundImageButton(editor) {
        // Listen for component selection changes
        editor.on('component:selected', (component) => {
            setTimeout(() => {
                injectBackgroundImageButton(editor);
            }, 100);
        });
        
        // Listen for style manager updates
        editor.on('styleManager:update:target', () => {
            setTimeout(() => {
                injectBackgroundImageButton(editor);
            }, 100);
        });
        
        // Also inject when sectors are opened
        editor.on('styleManager:change', () => {
            setTimeout(() => {
                injectBackgroundImageButton(editor);
            }, 100);
        });
        
        // Watch for when the Styles panel becomes visible
        const stylesPanel = document.getElementById('styles-panel');
        if (stylesPanel) {
            const observer = new MutationObserver(() => {
                if (stylesPanel.classList.contains('active')) {
                    setTimeout(() => {
                        injectBackgroundImageButton(editor);
                    }, 100);
                }
            });
            
            observer.observe(stylesPanel, {
                attributes: true,
                attributeFilter: ['class']
            });
        }
        
        // Inject initially after a delay
        setTimeout(() => {
            injectBackgroundImageButton(editor);
        }, 1000);
        
        console.log('✅ Background image button setup complete');
    }
    
    function injectBackgroundImageButton(editor) {
        // Find the decorations sector in the style manager
        const allSectors = document.querySelectorAll('.gjs-sm-sector');
        let decorationsSector = null;
        
        allSectors.forEach(sector => {
            const title = sector.querySelector('.gjs-sm-sector-title');
            if (title && title.textContent.trim() === 'Decorations') {
                decorationsSector = sector;
            }
        });
        
        if (!decorationsSector) {
            console.log('Decorations sector not found');
            return;
        }
        
        // Check if button already exists
        if (decorationsSector.querySelector('.background-image-button-wrapper')) {
            return;
        }
        
        // Find the properties container
        const propertiesContainer = decorationsSector.querySelector('.gjs-sm-properties');
        
        if (!propertiesContainer) {
            console.log('Properties container not found');
            return;
        }
        
        // Create button wrapper
        const buttonWrapper = document.createElement('div');
        buttonWrapper.className = 'gjs-sm-property gjs-sm-composite background-image-button-wrapper';
        buttonWrapper.style.cssText = 'padding: 8px 10px;';
        
        buttonWrapper.innerHTML = `
            <div class="gjs-sm-label">
                <span class="gjs-sm-label-text" title="Background Image">Background Image</span>
            </div>
            <div class="gjs-field-wrp gjs-field-wrp--button">
                <button type="button" class="gjs-field-button background-image-select-btn">
                    <i class="fa fa-images"></i> Select Image
                </button>
                <button type="button" class="gjs-field-button background-image-remove-btn" title="Remove background image">
                    <i class="fa fa-times"></i>
                </button>
            </div>
        `;
        
        // Add click handler to select button
        const selectButton = buttonWrapper.querySelector('.background-image-select-btn');
        selectButton.addEventListener('click', () => {
            const selected = editor.getSelected();
            if (selected) {
                console.log('Opening media library for background, component:', selected.get('tagName'));
                editor.runCommand('open-media-library', { 
                    target: selected,
                    mode: 'background'
                });
            }
        });
        
        // Add click handler to remove button
        const removeButton = buttonWrapper.querySelector('.background-image-remove-btn');
        removeButton.addEventListener('click', () => {
            const selected = editor.getSelected();
            if (selected) {
                console.log('Removing background image from:', selected.get('tagName'));
                selected.setStyle({
                    'background-image': 'none'
                });
                console.log('✅ Background image removed');
            }
        });
        
        // Insert at the beginning of properties
        propertiesContainer.insertBefore(buttonWrapper, propertiesContainer.firstChild);
        
        console.log('✅ Background image buttons injected');
    }
    
    // Initialize native color pickers for color input fields
    function initColorPickers(editor) {
        console.log('🎨 Initializing color pickers...');
        
        function setupColorInputs() {
            // Find all color input fields
            const colorInputs = document.querySelectorAll('.gjs-field-color, input.gjs-field-colorp, .gjs-clm-field-color');
            
            colorInputs.forEach(input => {
                // Skip if already initialized
                if (input.dataset.colorPickerInit) return;
                input.dataset.colorPickerInit = 'true';
                
                // Create a hidden HTML5 color input
                const colorPicker = document.createElement('input');
                colorPicker.type = 'color';
                colorPicker.className = 'native-color-picker-hidden';
                colorPicker.style.position = 'fixed';
                colorPicker.style.top = '50%';
                colorPicker.style.left = '50%';
                colorPicker.style.transform = 'translate(-50%, -50%)';
                colorPicker.style.opacity = '0';
                colorPicker.style.width = '1px';
                colorPicker.style.height = '1px';
                colorPicker.style.pointerEvents = 'auto';
                colorPicker.style.zIndex = '999999';
                
                // Set initial value
                const currentValue = input.value || '#000000';
                colorPicker.value = currentValue.startsWith('#') ? currentValue : '#' + currentValue;
                
                // Append to body for better positioning
                document.body.appendChild(colorPicker);
                
                // Store reference
                input.colorPickerElement = colorPicker;
                
                // Click on text input or its parent opens color picker
                const clickHandler = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Update color picker value before showing
                    const currentValue = input.value || '#000000';
                    colorPicker.value = currentValue.startsWith('#') ? currentValue : '#' + currentValue;
                    
                    // Position near click if possible, otherwise center
                    colorPicker.style.top = '50%';
                    colorPicker.style.left = '50%';
                    
                    // Trigger the native color picker
                    setTimeout(() => {
                        colorPicker.click();
                        colorPicker.focus();
                    }, 10);
                };
                
                input.addEventListener('click', clickHandler);
                
                // Also make parent clickable if it's the color preview container
                const parentContainer = input.closest('.gjs-field-colorp-c');
                if (parentContainer && !parentContainer.dataset.clickHandlerInit) {
                    parentContainer.dataset.clickHandlerInit = 'true';
                    parentContainer.addEventListener('click', clickHandler);
                    parentContainer.style.cursor = 'pointer';
                }
                
                // Make the input field look clickable
                input.style.cursor = 'pointer';
                input.readOnly = true;
                
                // When color is selected, update the text input
                colorPicker.addEventListener('input', (e) => {
                    input.value = e.target.value;
                    
                    // Update parent container background
                    const container = input.closest('.gjs-field-colorp-c');
                    if (container) {
                        container.style.setProperty('--color-value', e.target.value);
                        container.style.backgroundColor = e.target.value;
                        container.setAttribute('data-color', e.target.value);
                    }
                    
                    // Update preview element if exists
                    const preview = container?.querySelector('.gjs-field-colorp-prev');
                    if (preview) {
                        preview.style.backgroundColor = e.target.value;
                    }
                    
                    // Trigger change event for GrapesJS
                    const changeEvent = new Event('input', { bubbles: true });
                    input.dispatchEvent(changeEvent);
                });
                
                // Also trigger on change (when picker is closed)
                colorPicker.addEventListener('change', (e) => {
                    input.value = e.target.value;
                    
                    // Update parent container background
                    const container = input.closest('.gjs-field-colorp-c');
                    if (container) {
                        container.style.setProperty('--color-value', e.target.value);
                        container.style.backgroundColor = e.target.value;
                        container.setAttribute('data-color', e.target.value);
                    }
                    
                    // Update preview element if exists
                    const preview = container?.querySelector('.gjs-field-colorp-prev');
                    if (preview) {
                        preview.style.backgroundColor = e.target.value;
                    }
                    
                    const changeEvent = new Event('change', { bubbles: true });
                    input.dispatchEvent(changeEvent);
                });
                
                // Set initial color display
                const container = input.closest('.gjs-field-colorp-c');
                if (container) {
                    const initialColor = input.value || '#000000';
                    const colorValue = initialColor.startsWith('#') ? initialColor : '#' + initialColor;
                    container.style.setProperty('--color-value', colorValue);
                    container.style.backgroundColor = colorValue;
                    container.setAttribute('data-color', colorValue);
                }
                
                console.log('✅ Color picker added to:', input);
            });
        }
        
        // Initial setup
        setTimeout(setupColorInputs, 500);
        
        // Re-setup when component is selected
        editor.on('component:selected', () => {
            setTimeout(setupColorInputs, 200);
        });
        
        // Re-setup when style manager updates
        editor.on('styleManager:update:target', () => {
            setTimeout(setupColorInputs, 200);
        });
    }

    // Panel tab switching
    function setupPanelTabs() {
        document.querySelectorAll('.panel-tab').forEach(tab => {
            tab.addEventListener('click', function() {
                const panel = this.dataset.panel;

                // Update tab active state
                document.querySelectorAll('.panel-tab').forEach(t => t.classList.remove('active'));
                this.classList.add('active');

                // Update panel content
                document.querySelectorAll('.panel-section').forEach(p => p.classList.remove('active'));
                document.getElementById(panel + '-panel').classList.add('active');
            });
        });
    }

    // Toolbar buttons
    function setupToolbarButtons(editor) {
        // Save button
        document.getElementById('btn-save').addEventListener('click', () => {
            savePage(editor);
        });

        // Auto-save toggle
        document.getElementById('btn-autosave').addEventListener('click', function() {
            autoSaveEnabled = !autoSaveEnabled;

            // Save preference to cookie
            CookieManager.set('pagebuilder_autosave', autoSaveEnabled.toString());

            if (autoSaveEnabled) {
                this.classList.add('active');
                this.title = 'Auto-save is ON - Click to disable';
                showNotification('✅ Auto-save enabled', 'success');
                // Start auto-save
                startAutoSave(editor);
            } else {
                this.classList.remove('active');
                this.title = 'Auto-save is OFF - Click to enable';
                showNotification('⏸️ Auto-save disabled', 'info');
                // Stop auto-save
                if (autoSaveInterval) {
                    clearInterval(autoSaveInterval);
                    autoSaveInterval = null;
                }
            }
        });

        // Undo/Redo
        document.getElementById('btn-undo').addEventListener('click', () => {
            editor.runCommand('core:undo');
        });

        document.getElementById('btn-redo').addEventListener('click', () => {
            editor.runCommand('core:redo');
        });

        // Preview
        document.getElementById('btn-preview').addEventListener('click', () => {
            const commands = editor.Commands;
            if (commands.isActive('preview')) {
                commands.stop('preview');
            } else {
                commands.run('preview');
            }
        });

        // Code view
        document.getElementById('btn-code').addEventListener('click', () => {
            try {
                console.log('Code button clicked');
                showCodeModal(editor);
            } catch (error) {
                console.error('Error opening code modal:', error);
                showNotification('❌ Error opening code modal: ' + error.message, 'error');
            }
        });

        // Export as HTML
        document.getElementById('btn-export-html').addEventListener('click', () => {
            try {
                console.log('Export HTML button clicked');
                exportAsHTML(editor);
            } catch (error) {
                console.error('Error exporting HTML:', error);
                showNotification('❌ Error exporting HTML: ' + error.message, 'error');
            }
        });

        // Device switchers
        document.getElementById('btn-desktop').addEventListener('click', function() {
            editor.setDevice('Desktop');
            document.body.classList.remove('gjs-device-tablet', 'gjs-device-mobile');
            updateDeviceButtons(this);
        });

        document.getElementById('btn-tablet').addEventListener('click', function() {
            editor.setDevice('Tablet');
            document.body.classList.remove('gjs-device-mobile');
            document.body.classList.add('gjs-device-tablet');
            updateDeviceButtons(this);
        });

        document.getElementById('btn-mobile').addEventListener('click', function() {
            editor.setDevice('Mobile');
            document.body.classList.remove('gjs-device-tablet');
            document.body.classList.add('gjs-device-mobile');
            updateDeviceButtons(this);
        });
    }

    function updateDeviceButtons(active) {
        document.querySelectorAll('[id^="btn-device"], [id^="btn-desktop"], [id^="btn-tablet"], [id^="btn-mobile"]')
            .forEach(btn => btn.classList.remove('active'));
        active.classList.add('active');
    }

    // Save functionality
    function savePage(editor, isAutoSave = false) {
        const wrapper = editor.getWrapper();
        const bodyContainer = wrapper.find('#page-body')[0];

        if (!bodyContainer) {
            if (!isAutoSave) {
                alert('Error: Body container not found!');
            }
            return;
        }

        const bodyHtml = editor.getHtml({ component: bodyContainer });
        const bodyCss = editor.getCss({ component: bodyContainer });
        const bodyComponents = JSON.stringify(bodyContainer.toJSON());

        const data = {
            html: bodyHtml,
            css: bodyCss,
            components: bodyComponents,
            timestamp: new Date().toISOString()
        };

        const saveBtn = document.getElementById('btn-save');
        const originalHtml = saveBtn.innerHTML;

        // Only show button feedback for manual saves
        if (!isAutoSave) {
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            saveBtn.disabled = true;
        }

        fetch(window.PAGEBUILDER_CONFIG.apiEndpoints.save, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                if (isAutoSave) {
                    console.log('✅ Auto-saved successfully at', new Date().toLocaleTimeString());
                    // Small subtle notification for auto-save
                    const autoSaveBtn = document.getElementById('btn-autosave');
                    if (autoSaveBtn && autoSaveBtn.classList.contains('active')) {
                        // Brief pulse effect
                        autoSaveBtn.style.transform = 'scale(1.1)';
                        setTimeout(() => {
                            autoSaveBtn.style.transform = 'scale(1)';
                        }, 200);
                    }
                } else {
                    showNotification('✅ Page saved successfully!', 'success');
                }
            } else {
                if (!isAutoSave) {
                    showNotification('❌ Save failed: ' + result.message, 'error');
                }
            }
        })
        .catch(error => {
            if (!isAutoSave) {
                showNotification('❌ Save error: ' + error.message, 'error');
            } else {
                console.error('Auto-save error:', error);
            }
        })
        .finally(() => {
            if (!isAutoSave) {
                saveBtn.innerHTML = originalHtml;
                saveBtn.disabled = false;
            }
        });
    }

    // Load functionality
    function loadPage(editor) {
        fetch(window.PAGEBUILDER_CONFIG.apiEndpoints.load)
        .then(response => response.json())
        .then(result => {
            if (result.success && result.data) {
                const wrapper = editor.getWrapper();
                const bodyContainer = wrapper.find('#page-body')[0];

                if (bodyContainer && result.data.components) {
                    const components = JSON.parse(result.data.components);
                    bodyContainer.components(components.components || components);

                    if (result.data.css) {
                        editor.setStyle(result.data.css);
                    }

                    console.log('✅ Page loaded successfully');
                }
            }
        })
        .catch(error => {
            console.log('ℹ️ No saved page to load');
        });
    }

    // Save/Load setup
    function setupSaveLoad(editor) {
        // Start auto-save only if enabled (loaded from cookie)
        if (autoSaveEnabled) {
            startAutoSave(editor);
        }
        
        // Set initial button state based on cookie
        const autosaveBtn = document.getElementById('btn-autosave');
        if (autosaveBtn) {
            if (autoSaveEnabled) {
                autosaveBtn.classList.add('active');
                autosaveBtn.title = 'Auto-save is ON - Click to disable';
            } else {
                autosaveBtn.classList.remove('active');
                autosaveBtn.title = 'Auto-save is OFF - Click to enable';
            }
        }
    }

    // Start auto-save function
    function startAutoSave(editor) {
        if (autoSaveInterval) {
            clearInterval(autoSaveInterval);
        }
        autoSaveInterval = setInterval(() => {
            if (autoSaveEnabled) {
                console.log('💾 Auto-saving...');
                savePage(editor, true); // Pass true to indicate auto-save
            }
        }, 60000); // 60 seconds
    }

    // Code modal
    function showCodeModal(editor) {
        console.log('showCodeModal called');

        try {
            const wrapper = editor.getWrapper();
            console.log('Wrapper:', wrapper);

            const bodyContainer = wrapper.find('#page-body')[0];
            console.log('Body container:', bodyContainer);

            let html = '';
            let css = '';

            if (bodyContainer) {
                html = editor.getHtml({ component: bodyContainer });
                css = editor.getCss({ component: bodyContainer });
            } else {
                html = editor.getHtml();
                css = editor.getCss();
            }

            console.log('HTML length:', html.length, 'CSS length:', css.length);

            const modal = editor.Modal;
            console.log('Modal:', modal);

            modal.setTitle('📄 Export Code');

            const modalContent = document.createElement('div');
            modalContent.style.cssText = 'padding:20px;max-width:900px;margin:0 auto;background:white;';

            modalContent.innerHTML = `
            <div style="margin-bottom: 20px;">
                <h5 style="margin-bottom: 10px; color: #333;">HTML</h5>
                <textarea readonly id="html-code" style="width:100%;height:200px;font-family:'Courier New',monospace;font-size:13px;padding:10px;border:1px solid #ddd;border-radius:4px;background:#f8f9fa;">${html.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</textarea>
                <button id="copy-html-btn" style="margin-top:5px;padding:6px 12px;background:#28a745;color:white;border:none;border-radius:4px;cursor:pointer;font-size:13px;">
                    <i class="fas fa-copy"></i> Copy HTML
                </button>
            </div>
            <div style="margin-bottom: 20px;">
                <h5 style="margin-bottom: 10px; color: #333;">CSS</h5>
                <textarea readonly id="css-code" style="width:100%;height:200px;font-family:'Courier New',monospace;font-size:13px;padding:10px;border:1px solid #ddd;border-radius:4px;background:#f8f9fa;">${css}</textarea>
                <button id="copy-css-btn" style="margin-top:5px;padding:6px 12px;background:#28a745;color:white;border:none;border-radius:4px;cursor:pointer;font-size:13px;">
                    <i class="fas fa-copy"></i> Copy CSS
                </button>
            </div>
            <div style="text-align: center;">
                <button id="close-modal-btn" style="padding:10px 30px;background:#007bff;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px;font-weight:500;">
                    <i class="fas fa-times"></i> Close
                </button>
            </div>
        `;

        modal.setContent(modalContent);
        modal.open();

        // Add copy functionality
        setTimeout(() => {
            const copyHtmlBtn = document.getElementById('copy-html-btn');
            const copyCssBtn = document.getElementById('copy-css-btn');
            const closeBtn = document.getElementById('close-modal-btn');

            if (copyHtmlBtn) {
                copyHtmlBtn.addEventListener('click', () => {
                    const htmlCode = document.getElementById('html-code');
                    htmlCode.select();
                    document.execCommand('copy');
                    copyHtmlBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                    setTimeout(() => {
                        copyHtmlBtn.innerHTML = '<i class="fas fa-copy"></i> Copy HTML';
                    }, 2000);
                });
            }

            if (copyCssBtn) {
                copyCssBtn.addEventListener('click', () => {
                    const cssCode = document.getElementById('css-code');
                    cssCode.select();
                    document.execCommand('copy');
                    copyCssBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                    setTimeout(() => {
                        copyCssBtn.innerHTML = '<i class="fas fa-copy"></i> Copy CSS';
                    }, 2000);
                });
            }

            if (closeBtn) {
                closeBtn.addEventListener('click', () => {
                    console.log('Close button clicked');
                    modal.close();
                });
            } else {
                console.error('Close button not found');
            }
        }, 100);

        console.log('Modal opened successfully');

        } catch (error) {
            console.error('Error in showCodeModal:', error);
            alert('Error opening code modal: ' + error.message);
        }
    }

    // Export as HTML file (content only, without header and footer)
    function exportAsHTML(editor) {
        try {
            const wrapper = editor.getWrapper();
            const bodyContainer = wrapper.find('#page-body')[0];

            let html = '';
            let css = '';

            if (bodyContainer) {
                html = editor.getHtml({ component: bodyContainer });
                css = editor.getCss({ component: bodyContainer });
            } else {
                html = editor.getHtml();
                css = editor.getCss();
            }

            // Get any custom JavaScript from the page (if exists)
            let customJs = '';
            const scriptTags = bodyContainer ? bodyContainer.find('script') : [];
            scriptTags.forEach(script => {
                const scriptContent = script.get('content');
                if (scriptContent) {
                    customJs += scriptContent + '\n';
                }
            });

            // Build complete HTML document
            const fullHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exported Page - ${new Date().toLocaleDateString()}</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    
    <!-- Custom Styles -->
    <style>
${css}
    </style>
</head>
<body>

<!-- Page Content (without header and footer) -->
${html}

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

${customJs ? `<!-- Custom JavaScript -->\n<script>\n${customJs}\n</script>` : ''}

</body>
</html>`;

            // Create a blob and download
            const blob = new Blob([fullHTML], { type: 'text/html' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `page-export-${new Date().toISOString().slice(0,10)}.html`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            showNotification('✅ HTML file exported successfully!', 'success');
            console.log('✅ HTML exported');

        } catch (error) {
            console.error('Error in exportAsHTML:', error);
            showNotification('❌ Export failed: ' + error.message, 'error');
        }
    }

    // Notification system
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            background: ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : '#007bff'};
            color: white;
            border-radius: 4px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 999999;
            animation: slideIn 0.3s ease;
            max-width: 400px;
        `;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    window.showNotification = showNotification;

    // Component search functionality
    function setupBlockSearch(editor) {
        const searchInput = document.getElementById('block-search');
        if (!searchInput) {
            console.warn('⚠️ Block search input not found');
            return;
        }

        console.log('✅ Setting up block search');

        let allBlockViews = [];

        // Function to collect block views from GrapesJS
        const collectBlockViews = () => {
            allBlockViews = [];
            const blockManager = editor.BlockManager;
            const blocksContainer = document.getElementById('blocks');

            if (!blocksContainer) {
                console.warn('⚠️ Blocks container not found');
                return;
            }

            // Get all block views from GrapesJS
            const blockEls = blocksContainer.querySelectorAll('.gjs-block');
            console.log(`📦 Found ${blockEls.length} block elements`);

            blockEls.forEach(blockEl => {
                // Get the block ID from various possible attributes
                const blockId = blockEl.getAttribute('draggable') ||
                               blockEl.getAttribute('data-id') ||
                               blockEl.id;

                // Store block element with its text content
                const blockText = blockEl.textContent || blockEl.innerText || '';
                const blockTitle = blockEl.getAttribute('title') || '';

                allBlockViews.push({
                    element: blockEl,
                    id: blockId,
                    text: blockText.toLowerCase(),
                    title: blockTitle.toLowerCase()
                });
            });

            console.log(`✅ Collected ${allBlockViews.length} block views`);
        };

        // Collect blocks after editor loads
        setTimeout(collectBlockViews, 1000);

        // Re-collect if blocks change
        editor.on('block:add', () => {
            setTimeout(collectBlockViews, 100);
        });

        searchInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase().trim();

            console.log(`🔍 Searching for: "${searchTerm}"`);

            // If empty, show all
            if (!searchTerm) {
                allBlockViews.forEach(view => {
                    view.element.style.display = '';
                });
                document.querySelectorAll('.gjs-block-category').forEach(cat => {
                    cat.style.display = '';
                });

                // Remove no results message
                const noResultsMsg = document.getElementById('no-results-message');
                if (noResultsMsg) {
                    noResultsMsg.remove();
                }
                return;
            }

            // Re-collect blocks in case they changed
            if (allBlockViews.length === 0) {
                collectBlockViews();
            }

            // Hide all categories first
            const categories = new Set();
            document.querySelectorAll('.gjs-block-category').forEach(cat => {
                cat.style.display = 'none';
            });

            // Filter blocks
            let matchCount = 0;
            allBlockViews.forEach(view => {
                const matches = view.text.includes(searchTerm) ||
                               view.title.includes(searchTerm) ||
                               (view.id && view.id.toLowerCase().includes(searchTerm));

                if (matches) {
                    view.element.style.display = '';
                    matchCount++;

                    // Show parent category
                    const categoryElement = view.element.closest('.gjs-block-category');
                    if (categoryElement) {
                        categoryElement.style.display = '';
                    }
                } else {
                    view.element.style.display = 'none';
                }
            });

            // Show message if no matches
            let noResultsMsg = document.getElementById('no-results-message');
            if (matchCount === 0) {
                if (!noResultsMsg) {
                    noResultsMsg = document.createElement('div');
                    noResultsMsg.id = 'no-results-message';
                    noResultsMsg.style.cssText = 'padding: 20px; text-align: center; color: #999; font-size: 13px;';
                    noResultsMsg.innerHTML = `
                        <i class="fas fa-search" style="font-size: 32px; margin-bottom: 10px; display: block;"></i>
                        No components found for "${searchTerm}"
                    `;
                    const blocksContainer = document.getElementById('blocks');
                    if (blocksContainer) {
                        blocksContainer.appendChild(noResultsMsg);
                    }
                }
                console.log(`❌ No matches found for "${searchTerm}"`);
            } else {
                if (noResultsMsg) {
                    noResultsMsg.remove();
                }
                console.log(`✅ Found ${matchCount} matches for "${searchTerm}"`);
            }
        });

        console.log('✅ Block search initialized');
    }

})();

// Add animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(400px); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(400px); opacity: 0; }
    }
`;
document.head.appendChild(style);
